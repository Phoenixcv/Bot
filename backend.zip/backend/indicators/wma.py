import pandas as pd
import numpy as np

def calculate_wma(series, window=20):
    weights = np.arange(1, window + 1)
    return series.rolling(window).apply(lambda prices: np.dot(prices, weights) / weights.sum(), raw=True)
