
import requests
import time

BASE_URL = "http://localhost:8000"

def test_connection():
    print("🔌 Проверка подключения...")
    try:
        r = requests.get(BASE_URL + "/")
        print("✅ Backend доступен")
    except Exception as e:
        print("❌ Backend недоступен:", e)

def test_settings():
    print("\n⚙️ Тест настроек")
    r = requests.get(BASE_URL + "/settings")
    print("Получено:", r.json())

    print("Обновление настроек...")
    patch = {
        "mode": "autonomous",
        "model": "gpt-3.5",
        "deal_type": "percent",
        "deal_value": 25
    }
    r = requests.patch(BASE_URL + "/settings", json=patch)
    print("Ответ:", r.json())

def test_balance_and_limit():
    print("\n💰 Тест баланса и лимитов")

    print("Получение сводки /wallet/summary")
    r = requests.get(BASE_URL + "/wallet/summary")
    print("Сводка:", r.json())

    print("Обновление лимита на 250 USDT")
    r = requests.post(BASE_URL + "/wallet/limit", json={"new_limit": 250})
    print("Ответ:", r.json())

    print("Зарезервировать 50 USDT")
    r = requests.post(BASE_URL + "/wallet/use", json={"amount": 50})
    print("Ответ:", r.json())

    print("Вернуть 10 USDT в баланс")
    r = requests.post(BASE_URL + "/wallet/return", json={"amount": 10})
    print("Ответ:", r.json())

def test_symbols_and_analysis():
    print("\n📈 Тест символов и анализа")

    r = requests.get(BASE_URL + "/symbols")
    print("Символы:", r.json())

    print("Обновление выбранных символов...")
    r = requests.patch(BASE_URL + "/settings", json={"symbols": ["BTCUSDT", "ETHUSDT"]})
    print("Ответ:", r.json())

    print("Получение анализа по /analyze")
    r = requests.get(BASE_URL + "/analyze")
    print("Анализ:", r.json())

def test_active_trades():
    print("\n📊 Тест активных сделок")

    r = requests.get(BASE_URL + "/wallet/active_trades")
    print("Активные сделки:", r.json())

def test_bot_start():
    print("\n🤖 Тест запуска бота")

    r = requests.post(BASE_URL + "/bot/start", json={})
    print("Запуск:", r.json())

def test_all():
    test_connection()
    test_settings()
    test_balance_and_limit()
    test_symbols_and_analysis()
    test_active_trades()
    test_bot_start()

if __name__ == "__main__":
    test_all()
