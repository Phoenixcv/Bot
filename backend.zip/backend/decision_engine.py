import os
from dotenv import load_dotenv
from openai import OpenAI
from market_analyzer import get_market_analysis, calculate_signal_score
from utils.settings_manager import load_settings
from utils.wallet_manager import get_available, update_used, return_to_balance
from trade_manager import (
    should_open_trade,
    should_close_trade,
    register_trade,
    close_trade,
    load_active_trades
)
from history_logger import log_trade
from utils.signal_logger import log_decision
import json
from datetime import datetime

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GPT_MODEL = os.getenv("GPT_MODEL", "gpt-3.5-turbo")
chatgpt_connected = False
client = None

if OPENAI_API_KEY:
    client = OpenAI(api_key=OPENAI_API_KEY)
    chatgpt_connected = True
else:
    print("[WARNING] OPENAI_API_KEY отсутствует. AI будет недоступен.")
    chatgpt_connected = False

DEBUG_LOG_PATH = "logs/debug_log.json"

def log_debug(entry: dict):
    os.makedirs("logs", exist_ok=True)
    entry["timestamp"] = datetime.utcnow().isoformat()
    try:
        if os.path.exists(DEBUG_LOG_PATH):
            with open(DEBUG_LOG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
        else:
            data = []
        data.append(entry)
        data = data[-500:]
        with open(DEBUG_LOG_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print("[DEBUG LOG ERROR]", e)

def make_decision(symbol: str, mode: str = None):
    global chatgpt_connected

    settings = load_settings()
    trade_mode = settings.get("trade_mode", "hourly")
    decision_mode = settings.get("mode", "hybrid")
    max_open_trades = settings.get("max_open_trades", 3)
    auto_close_enabled = settings.get("enable_auto_close", True)
    entry_threshold = settings.get("entry_threshold", 0.75)
    exit_threshold = settings.get("exit_threshold", 0.6)
    debug_enabled = settings.get("debug", False)

    if not mode:
        mode = trade_mode

    analysis = get_market_analysis(symbol, mode=mode)
    score = calculate_signal_score(analysis)
    price = analysis.get("price", 0)

    print(f"[DECISION] {symbol} | score={score:.4f} | mode={decision_mode} | price={price}")

    recommendation = "hold"
    reason = "Недостаточно данных"
    chatgpt_decision = None
    ai_confirmation = False

    # === AI или Гибрид ===
    if decision_mode in ["ai", "hybrid"] and chatgpt_connected:
        prompt = (
            f"Ты — торговый аналитик. Вот анализ по {symbol} в режиме {mode}:\n"
            f"{analysis}\n\n"
            f"На основе данных, выбери одно: 'buy', 'sell', 'hold'. Объясни в 1-2 предложениях."
        )
        try:
            response = client.chat.completions.create(
                model=GPT_MODEL,
                messages=[
                    {"role": "system", "content": "Ты — опытный крипто-аналитик."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.4
            )
            content = response.choices[0].message.content.strip()
            chatgpt_decision = content
            ai_confirmation = True

            if "buy" in content.lower():
                recommendation = "buy"
            elif "sell" in content.lower():
                recommendation = "sell"
            else:
                recommendation = "hold"

            reason = content
            print(f"[CHATGPT] {symbol}: {recommendation.upper()} | Обоснование: {content}")

        except Exception as e:
            chatgpt_connected = False
            recommendation = "hold"
            reason = f"ChatGPT недоступен: {str(e)}"
            ai_confirmation = False
            print(f"[ERROR] Ошибка ChatGPT: {e}")

    # === Fallback / Автономный режим ===
    if decision_mode == "autonomous" or not chatgpt_connected:
        print(f"[FALLBACK] Используется автономный режим для {symbol}")
        active = load_active_trades()
        if should_open_trade(symbol, score):
            if len([t for t in active.values() if t["status"] == "open"]) < max_open_trades:
                recommendation = "buy"
                reason = f"Сигнал на вход: score={score:.2f} ≥ {entry_threshold}"
        elif auto_close_enabled and should_close_trade(symbol, score, price):
            recommendation = "sell"
            reason = f"Сигнал на выход: score={score:.2f} < {exit_threshold}"
        else:
            recommendation = "hold"
            reason = "Нет условий для входа или выхода"

    balance_limit = float(settings.get("balance_limit", 100.0))
    deal_type = settings.get("deal_type", "percent")
    deal_value = float(settings.get("deal_value", 25))

    if deal_type == "percent":
        usdt_to_spend = (balance_limit * deal_value) / 100
    elif deal_type == "manual":
        usdt_to_spend = min(deal_value, balance_limit)
    else:
        usdt_to_spend = 10.0

    quantity = round(usdt_to_spend / price, 6) if price > 0 else 0

    decision_data = {
        "recommendation": recommendation,
        "reason": reason,
        "score": round(score, 4),
        "mode": decision_mode if chatgpt_connected else "fallback",
        "chatgpt_decision": chatgpt_decision,
        "ai_confirmation": ai_confirmation,
        "analysis": analysis,
        "quantity": quantity,
        "usdt_to_spend": round(usdt_to_spend, 2)
    }

    log_decision(symbol, decision_data)

    if debug_enabled:
        debug_entry = {
            "symbol": symbol,
            "price": price,
            "score": round(score, 4),
            "recommendation": recommendation,
            "reason": reason,
            "usdt_to_spend": round(usdt_to_spend, 2),
            "quantity": quantity,
            "balance_limit": balance_limit,
            "threshold": entry_threshold,
            "mode": decision_mode
        }
        log_debug(debug_entry)

    return decision_data
