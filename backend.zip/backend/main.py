from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os
import asyncio
from binance.client import Client

# Импорт роутов
from routes.analyze import router as analyze_router
from routes.trade import router as trade_router
from routes.settings import router as settings_router
from routes.api_keys import router as api_keys_router
from routes.history import router as history_router
from routes.decision import router as decision_router
from routes.status import router as status_router
from routes.analyze_summary import router as analyze_summary_router
from routes.wallet import router as wallet_router
from routes.bot import router as bot_router

# Утилиты и логика
from utils.settings_manager import load_settings, get_env_keys, get_reserved_usdt
from utils.wallet_manager import update_used, return_to_balance, reset_reserved_if_no_trades
from utils.signal_logger import log_signal
from utils.event_logger import log_event
from decision_engine import make_decision
from history_logger import log_trade
from trade_manager import should_open_trade, should_close_trade, register_trade, close_trade

# === Загрузка .env ===
load_dotenv()

# === Инициализация приложения ===
app = FastAPI()

# === Разрешения CORS ===
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === Настройка Binance ===
env_keys = get_env_keys(masked=False)
use_testnet = os.getenv("USE_TESTNET", "true").lower() == "true"

API_KEY = env_keys.get("binance_api_key_test") if use_testnet else env_keys.get("binance_api_key_main")
API_SECRET = env_keys.get("binance_secret_key_test") if use_testnet else env_keys.get("binance_secret_key_main")

if not API_KEY or not API_SECRET:
    raise EnvironmentError("❌ API ключи Binance не найдены. Проверь .env файл или настройки.")

client = Client(API_KEY, API_SECRET)
client.API_URL = "https://testnet.binance.vision/api" if use_testnet else "https://api.binance.com/api"

# === Статус сервера ===
@app.get("/")
def root():
    log_event("startup", "Сервер запущен и готов к торговле")
    return {"message": "✅ Торговый бот активен и готов к работе!"}

# === Баланс ===
@app.get("/balance")
def get_balance():
    try:
        account = client.get_account()
        balances = account.get("balances", [])
        non_zero = [b for b in balances if float(b.get("free", 0)) > 0 or float(b.get("locked", 0)) > 0]
        usdt_data = next((b for b in balances if b["asset"] == "USDT"), {"free": "0", "locked": "0"})
        reserved = get_reserved_usdt()

        return {
            "balance": non_zero,
            "usdt": {
                "free": usdt_data["free"],
                "locked": usdt_data["locked"],
                "reserved": reserved,
            },
        }
    except Exception as e:
        log_event("error", "Ошибка при получении баланса", {"exception": str(e)})
        return {"error": str(e)}

# === Фоновый анализатор ===
async def periodic_analyzer():
    while True:
        reset_reserved_if_no_trades()

        settings = load_settings()
        interval = settings.get("interval_minutes", 1)
        symbols = settings.get("symbols", ["BTCUSDT"])
        trade_mode = settings.get("trade_mode", "hourly")

        for symbol in symbols:
            try:
                decision = make_decision(symbol, mode=trade_mode)
                analysis = decision.get("analysis", {})
                score = decision.get("score", 0)
                quantity = decision.get("quantity", 0)
                usdt_to_spend = decision.get("usdt_to_spend", 0)

                log_signal(symbol, analysis, {
                    "recommendation": decision.get("recommendation"),
                    "score": score,
                    "reason": decision.get("reason"),
                    "mode": decision.get("mode"),
                    "chatgpt_decision": decision.get("chatgpt_decision"),
                    "ai_confirmation": decision.get("ai_confirmation"),
                })

                if decision.get("recommendation") == "buy" and should_open_trade(symbol, score):
                    order = client.order_market_buy(symbol=symbol, quantity=quantity)
                    fills = order.get("fills", [])
                    price = float(fills[0]["price"]) if fills else 0.0
                    update_used(usdt_to_spend)
                    register_trade(symbol, price, "buy")
                    log_trade(symbol, "BUY", price, quantity, decision)

                elif decision.get("recommendation") == "sell" and should_close_trade(symbol, score, analysis.get("price", 0)):
                    order = client.order_market_sell(symbol=symbol, quantity=quantity)
                    fills = order.get("fills", [])
                    price = float(fills[0]["price"]) if fills else 0.0
                    return_to_balance(price * quantity)
                    close_trade(symbol)
                    log_trade(symbol, "SELL", price, quantity, decision)

            except Exception as e:
                log_event("error", f"Ошибка анализа {symbol}", {"exception": str(e)})

        await asyncio.sleep(interval * 60)

# === Фоновый запуск ===
@app.on_event("startup")
async def startup_event():
    asyncio.create_task(periodic_analyzer())

# === Роуты ===
app.include_router(analyze_router)
app.include_router(trade_router)
app.include_router(settings_router)
app.include_router(api_keys_router)
app.include_router(history_router)
app.include_router(decision_router)
app.include_router(status_router)
app.include_router(analyze_summary_router)
app.include_router(wallet_router)
app.include_router(bot_router)
