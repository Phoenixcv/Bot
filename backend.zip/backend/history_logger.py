import json
import os
from datetime import datetime

LOGS_FOLDER = "logs"
LOG_FILE = os.path.join(LOGS_FOLDER, "trade_history.json")

# Убедимся, что папка logs существует
os.makedirs(LOGS_FOLDER, exist_ok=True)

def log_trade(symbol: str, action: str, price: float, quantity: float, decision: dict = None):
    """
    Логирует сделку с расширенными данными.
    """
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "symbol": symbol,
        "action": action,
        "price": round(price, 6),
        "quantity": round(quantity, 6),
    }

    # Включаем дополнительные поля, если есть решение
    if decision:
        entry["score"] = decision.get("score")
        entry["mode"] = decision.get("mode")
        entry["reason"] = decision.get("reason")
        entry["chatgpt_decision"] = decision.get("chatgpt_decision")
        analysis = decision.get("analysis", {})
        entry["trend"] = analysis.get("trend")
        entry["interval"] = analysis.get("mode")
        entry["indicators"] = list(analysis.keys())

    try:
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, "r") as f:
                history = json.load(f)
        else:
            history = []

        history.append(entry)

        with open(LOG_FILE, "w") as f:
            json.dump(history, f, indent=2)

        print(f"[HISTORY] LOGGED: {symbol} {action.upper()} {price} x {quantity}")

    except Exception as e:
        print(f"[HISTORY ERROR] {e}")
