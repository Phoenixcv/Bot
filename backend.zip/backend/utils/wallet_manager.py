import json
import os
from datetime import datetime
from trade_manager import load_active_trades

WALLET_FILE = "logs/wallet_status.json"

def init_wallet():
    if not os.path.exists(WALLET_FILE):
        with open(WALLET_FILE, "w") as f:
            json.dump({
                "total_balance": 1000.0,
                "trade_limit": 100.0,
                "used_in_trades": 0.0,
                "active_deals": []
            }, f, indent=2)

def load_wallet():
    init_wallet()
    with open(WALLET_FILE, "r") as f:
        return json.load(f)

def save_wallet(data):
    with open(WALLET_FILE, "w") as f:
        json.dump(data, f, indent=2)

def update_trade_limit(new_limit: float):
    wallet = load_wallet()
    wallet["trade_limit"] = max(0.0, round(new_limit, 2))
    wallet["used_in_trades"] = min(wallet["used_in_trades"], wallet["trade_limit"])
    save_wallet(wallet)

def update_used(amount: float):
    wallet = load_wallet()
    wallet["used_in_trades"] += amount
    wallet["used_in_trades"] = max(0.0, min(wallet["used_in_trades"], wallet["trade_limit"]))
    save_wallet(wallet)

def return_to_balance(amount: float):
    wallet = load_wallet()
    wallet["total_balance"] += max(0.0, round(amount, 2))
    wallet["used_in_trades"] = max(0.0, wallet["used_in_trades"] - round(amount, 2))
    save_wallet(wallet)

def can_allocate(amount: float):
    wallet = load_wallet()
    return wallet["used_in_trades"] + amount <= wallet["trade_limit"]

def get_available():
    wallet = load_wallet()
    return max(0.0, wallet["trade_limit"] - wallet["used_in_trades"])

def get_wallet_status():
    wallet = load_wallet()
    return {
        **wallet,
        "available_for_trade": round(get_available(), 2)
    }

def add_active_deal(symbol: str, entry_price: float, amount: float, trend: str, current_price: float, action: str):
    wallet = load_wallet()
    wallet.setdefault("active_deals", []).append({
        "symbol": symbol,
        "entry_price": round(entry_price, 4),
        "current_price": round(current_price, 4),
        "amount": round(amount, 4),
        "trend": trend,
        "action": action,
        "timestamp": datetime.utcnow().isoformat(),
        "status": "open"
    })
    save_wallet(wallet)

def close_deal(symbol: str, exit_price: float):
    wallet = load_wallet()
    for deal in wallet.get("active_deals", []):
        if deal["symbol"] == symbol and deal["status"] == "open":
            deal["status"] = "closed"
            deal["exit_price"] = round(exit_price, 4)
            deal["realized_pnl"] = round((exit_price - deal["entry_price"]) * deal["amount"], 4)
            break
    save_wallet(wallet)

def get_deals(active_only: bool = True):
    wallet = load_wallet()
    deals = wallet.get("active_deals", [])
    if active_only:
        return [d for d in deals if d["status"] == "open"]
    return deals

def reset_reserved_if_no_trades():
    active = load_active_trades()
    open_trades = [t for t in active.values() if t.get("status") == "open"]
    if not open_trades:
        wallet = load_wallet()
        wallet["used_in_trades"] = 0.0
        save_wallet(wallet)
