import os
from dotenv import load_dotenv
from binance.client import Client

load_dotenv()

API_KEY = os.getenv("BINANCE_API_KEY")
API_SECRET = os.getenv("BINANCE_SECRET_KEY")
USE_TESTNET = os.getenv("USE_TESTNET", "true").lower() == "true"

if not API_KEY or not API_SECRET:
    raise RuntimeError("❌ Binance API ключи не найдены в .env файле!")

client = Client(API_KEY, API_SECRET, testnet=USE_TESTNET)

# Принудительно установить endpoint для тестнета
if USE_TESTNET:
    client.API_URL = "https://testnet.binance.vision/api"

def get_client():
    return client
