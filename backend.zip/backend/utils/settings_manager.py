import json
import os
from datetime import datetime
from dotenv import dotenv_values

SETTINGS_FILE = "user_settings.json"
ENV_FILE = ".env"
KEY_HISTORY_FILE = "logs/key_history.json"

DEFAULT_SETTINGS = {
    "model": "gpt-3.5-turbo",
    "interval_minutes": 1,
    "mode": "ai",
    "balance_limit": 100.0,
    "threshold_score": 0.6,
    "symbols": ["BTCUSDT"],
    "trade_mode": "hourly",
    "entry_threshold": 0.75,
    "exit_threshold": 0.6,
    "max_open_trades": 3,
    "trade_risk": 0.1,
    "trailing": True,
    "enable_auto_close": True,
    "trailing_stop_pct": 2.0,
    "take_profit_pct": 5.0,
    "stop_loss_pct": 3.0,
    "indicator_weights": {
        "rsi": 0.3,
        "macd": 0.3,
        "ema_trend": 0.2,
        "sma_trend": 0.2
    }
}


def load_settings():
    if not os.path.exists(SETTINGS_FILE):
        save_settings(DEFAULT_SETTINGS)
    with open(SETTINGS_FILE, "r") as f:
        data = json.load(f)
    updated = False
    for key, default_value in DEFAULT_SETTINGS.items():
        if key not in data:
            data[key] = default_value
            updated = True
    if updated:
        save_settings(data)
    return data


def save_settings(new_settings):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(new_settings, f, indent=2)


def update_settings(updated_fields):
    settings = load_settings()
    for key, value in updated_fields.items():
        if key in DEFAULT_SETTINGS:
            settings[key] = value
        elif key == "indicator_weights" and isinstance(value, dict):
            settings["indicator_weights"].update(value)
    save_settings(settings)
    return settings


def update_env_file(updates: dict):
    current = dotenv_values(ENV_FILE)
    os.makedirs("logs", exist_ok=True)
    history = []

    for key, new_val in updates.items():
        old_val = current.get(key, "")
        if old_val != new_val:
            current[key] = new_val
            history.append({
                "timestamp": datetime.utcnow().isoformat(),
                "key": key,
                "old": old_val[:6] + "***" if old_val else "",
                "new": new_val[:6] + "***"
            })

    with open(ENV_FILE, "w") as f:
        for k, v in current.items():
            f.write(f"{k}={v}\n")

    if history:
        log = []
        if os.path.exists(KEY_HISTORY_FILE):
            with open(KEY_HISTORY_FILE, "r") as f:
                log = json.load(f)
        log.extend(history)
        with open(KEY_HISTORY_FILE, "w") as f:
            json.dump(log, f, indent=2)


def get_env_keys(masked: bool = True):
    keys = dotenv_values(ENV_FILE)
    result = {
        "binance_api_key_test": keys.get("BINANCE_API_KEY_TEST", ""),
        "binance_secret_key_test": keys.get("BINANCE_SECRET_KEY_TEST", ""),
        "binance_api_key_main": keys.get("BINANCE_API_KEY_MAIN", ""),
        "binance_secret_key_main": keys.get("BINANCE_SECRET_KEY_MAIN", ""),
        "chatgpt_key": keys.get("OPENAI_API_KEY", ""),
        "use_testnet": keys.get("USE_TESTNET", "true").lower() == "true"
    }

    if masked:
        for k in result:
            val = result[k]
            result[k] = val[:6] + "***" if isinstance(val, str) and val else val

    return result


def get_reserved_usdt():
    settings = load_settings()
    return float(settings.get("balance_limit", 0.0))
