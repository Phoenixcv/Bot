import json
import os
from datetime import datetime

# Пути к логам
SIGNAL_LOG_PATH = os.path.join("logs", "signal_log.json")
TRADE_HISTORY_PATH = os.path.join("logs", "trade_history.json")
DECISION_LOG_PATH = os.path.join("logs", "decision_log.json")  # ✅ новый лог

def _ensure_file_exists(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.exists(path):
        with open(path, 'w', encoding='utf-8') as f:
            f.write("")

def log_signal(symbol, analysis_data, decision):
    """Логирует торговый сигнал в signal_log.json (построчно)."""
    _ensure_file_exists(SIGNAL_LOG_PATH)

    log_entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "symbol": symbol,
        "analysis": analysis_data,
        "decision": decision
    }

    try:
        with open(SIGNAL_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
        print(f"[SIGNAL] LOGGED: {symbol}")
    except Exception as e:
        print(f"[SIGNAL LOG ERROR] {e}")

def log_trade(symbol, action, price, quantity, decision_data=None):
    """Логирует совершённую сделку в trade_history.json (построчно)."""
    _ensure_file_exists(TRADE_HISTORY_PATH)

    trade_entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "symbol": symbol,
        "action": action,
        "price": price,
        "quantity": quantity,
        "decision": decision_data or {}
    }

    try:
        with open(TRADE_HISTORY_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(trade_entry, ensure_ascii=False) + "\n")
        print(f"[TRADE] LOGGED: {symbol} {action.upper()} {price} x {quantity}")
    except Exception as e:
        print(f"[TRADE LOG ERROR] {e}")

def log_decision(symbol, decision):
    """Логирует решение (AI / fallback) в decision_log.json (построчно)."""
    _ensure_file_exists(DECISION_LOG_PATH)

    log_entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "symbol": symbol,
        **decision
    }

    try:
        with open(DECISION_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
        print(f"[DECISION] LOGGED: {symbol} => {decision.get('recommendation', 'N/A')}")
    except Exception as e:
        print(f"[DECISION LOG ERROR] {e}")
