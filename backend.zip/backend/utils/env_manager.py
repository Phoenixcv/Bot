import os
import json
from dotenv import load_dotenv, set_key, dotenv_values
from datetime import datetime

ENV_FILE = ".env"
KEY_LOG_FILE = "logs/api_keys_history.log"

load_dotenv(ENV_FILE)
os.makedirs("logs", exist_ok=True)

SENSITIVE_KEYS = [
    "BINANCE_API_KEY_TEST", "BINANCE_SECRET_KEY_TEST",
    "BINANCE_API_KEY_MAIN", "BINANCE_SECRET_KEY_MAIN",
    "OPENAI_API_KEY"
]

def get_env_key(key_name: str) -> str:
    return os.getenv(key_name, "")

def get_all_keys():
    """
    Возвращает все ключи (не маскируется)
    """
    return dotenv_values(ENV_FILE)

def update_env_file(updates: dict):
    """
    Обновляет .env файл без логирования
    """
    for key, value in updates.items():
        set_key(ENV_FILE, key, value)

def update_keys_with_history(new_keys: dict):
    """
    Обновляет ключи в .env и логирует изменения в формате для frontend
    """
    current = dotenv_values(ENV_FILE)
    updated_keys = {}

    for key in SENSITIVE_KEYS:
        new_val = new_keys.get(key)
        if new_val and current.get(key) != new_val:
            set_key(ENV_FILE, key, new_val)
            updated_keys[key] = mask_key(new_val)

    if updated_keys:
        log_key_history(updated_keys)

def mask_key(value: str) -> str:
    """
    Маскирует ключ: первые 4 символа + '****'
    """
    if not value:
        return "(empty)"
    return value[:4] + "****"

def log_key_history(updated_keys: dict):
    """
    Логирует изменения в формате:
    {
      "timestamp": "...",
      "source": "web",
      "updated_keys": {
        "KEY": "xxxx****"
      }
    }
    """
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "source": "web",
        "updated_keys": updated_keys
    }

    try:
        if os.path.exists(KEY_LOG_FILE):
            with open(KEY_LOG_FILE, "r", encoding="utf-8") as f:
                history = json.load(f)
        else:
            history = []

        history.append(entry)

        with open(KEY_LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2, ensure_ascii=False)

    except Exception as e:
        print("[KEY LOGGING ERROR]", e)

def load_key_history():
    """
    Загружает историю ключей (для отображения на фронте)
    """
    if not os.path.exists(KEY_LOG_FILE):
        return []
    try:
        with open(KEY_LOG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print("[LOAD HISTORY ERROR]", e)
        return []
