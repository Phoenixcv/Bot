import os
import random
import pandas as pd
from datetime import datetime, timedelta
from binance.client import Client
from dotenv import load_dotenv

from indicators.atr import calculate_atr
from indicators.bollinger import calculate_bollinger_bands
from indicators.ema import calculate_ema
from indicators.macd import calculate_macd
from indicators.momentum import calculate_momentum
from indicators.rsi import calculate_rsi
from indicators.sma import calculate_sma
from indicators.stochastic import calculate_stochastic
from indicators.wma import calculate_wma

load_dotenv()

API_KEY = os.getenv("binance_api_key")
API_SECRET = os.getenv("binance_secret_key")

client = Client(API_KEY, API_SECRET, testnet=True)

def get_market_analysis(symbol: str, mode: str = "hourly") -> dict:
    print(f"[ANALYSIS START] symbol={symbol} mode={mode}")

    interval_map = {
        "15m": "15m",
        "30m": "30m",
        "1h": "1h",
        "hourly": "1h",
        "daily": "1d",
        "weekly": "1w"
    }

    interval = interval_map.get(mode, "1h")

    try:
        klines = client.get_klines(symbol=symbol, interval=interval, limit=100)
        if not klines or len(klines) < 20:
            raise Exception("Недостаточно данных с Binance")

        df = pd.DataFrame(klines, columns=[
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_asset_volume", "number_of_trades",
            "taker_buy_base", "taker_buy_quote", "ignore"
        ])

        df["high"] = df["high"].astype(float)
        df["low"] = df["low"].astype(float)
        df["close"] = df["close"].astype(float)

        atr_series = calculate_atr(df, period=14)
        upper_bb, middle_bb, lower_bb = calculate_bollinger_bands(df["close"], window=20, num_std=2)
        ema = calculate_ema(df["close"], span=20).iloc[-1]
        sma = calculate_sma(df["close"], window=20).iloc[-1]
        wma = calculate_wma(df["close"], window=20).iloc[-1]
        macd_series, signal_line = calculate_macd(df["close"])
        macd = macd_series.iloc[-1]
        macd_signal = signal_line.iloc[-1]
        momentum = calculate_momentum(df["close"].tolist(), period=10)
        rsi_series = calculate_rsi(df["close"], period=14)
        rsi = rsi_series.iloc[-1] if not rsi_series.isna().all() else None
        stochastic_k, stochastic_d = calculate_stochastic(df["high"], df["low"], df["close"])

        price = round(df["close"].iloc[-1], 2)
        trend = "neutral"
        if ema and price > ema and sma and price > sma:
            trend = "bullish"
        elif ema and price < ema and sma and price < sma:
            trend = "bearish"

        analysis = {
            "symbol": symbol,
            "price": price,
            "trend": trend,
            "mode": mode,
            "atr": round(atr_series.iloc[-1], 4) if not atr_series.isna().all() else None,
            "bollinger_upper": round(upper_bb, 4),
            "bollinger_middle": round(middle_bb, 4),
            "bollinger_lower": round(lower_bb, 4),
            "ema": round(ema, 4),
            "sma": round(sma, 4),
            "wma": round(wma, 4),
            "macd": round(macd, 4),
            "macd_signal": round(macd_signal, 4),
            "momentum": round(momentum, 4) if momentum is not None else None,
            "rsi": round(rsi, 4) if rsi is not None else None,
            "stochastic_k": round(stochastic_k, 4),
            "stochastic_d": round(stochastic_d, 4),
            "timestamp": datetime.utcnow().isoformat()
        }

        print("[ANALYSIS RESULT]", analysis)
        return analysis

    except Exception as e:
        print("[MARKET ANALYSIS FALLBACK]", str(e))
        # fallback — заглушка
        fallback = {
            "symbol": symbol,
            "price": round(random.uniform(90, 110), 2),
            "trend": random.choice(["bullish", "bearish", "neutral"]),
            "mode": mode,
            "atr": 5.5,
            "bollinger_upper": 110,
            "bollinger_middle": 100,
            "bollinger_lower": 90,
            "ema": 101.1,
            "sma": 100.5,
            "wma": 100.8,
            "macd": 1.23,
            "macd_signal": 1.01,
            "momentum": 2.34,
            "rsi": 55.0,
            "stochastic_k": 60.5,
            "stochastic_d": 55.4,
            "timestamp": datetime.utcnow().isoformat()
        }
        return fallback

def calculate_signal_score(analysis: dict) -> float:
    trend = analysis.get("trend", "").lower()
    atr = analysis.get("atr", 0)
    price = analysis.get("price", 0)
    upper = analysis.get("bollinger_upper")
    lower = analysis.get("bollinger_lower")
    ema = analysis.get("ema", 0)
    sma = analysis.get("sma", 0)
    wma = analysis.get("wma", 0)
    macd = analysis.get("macd", 0)
    macd_signal = analysis.get("macd_signal", 0)
    momentum = analysis.get("momentum")
    rsi = analysis.get("rsi")
    stochastic_k = analysis.get("stochastic_k")
    stochastic_d = analysis.get("stochastic_d")

    base_score = {
        "bullish": 0.9,
        "bearish": 0.1,
        "neutral": 0.5
    }.get(trend, 0.5)

    if atr:
        base_score *= max(0.8 - (atr / 100), 0.5)

    if upper and lower:
        if price > upper:
            base_score *= 0.7
        elif price < lower:
            base_score *= 1.1

    if ema:
        base_score *= 1.05 if price > ema else 0.95

    if sma:
        base_score *= 1.03 if price > sma else 0.97

    if wma:
        base_score *= 1.04 if price > wma else 0.96

    if macd and macd_signal:
        base_score *= 1.05 if macd > macd_signal else 0.95

    if momentum is not None:
        base_score *= 1.03 if momentum > 0 else 0.97

    if rsi is not None:
        if rsi > 70:
            base_score *= 0.9
        elif rsi < 30:
            base_score *= 1.1

    if stochastic_k is not None and stochastic_d is not None:
        if stochastic_k > 80 and stochastic_d > 80:
            base_score *= 0.9
        elif stochastic_k < 20 and stochastic_d < 20:
            base_score *= 1.1

    return round(min(max(base_score, 0), 1), 4)
