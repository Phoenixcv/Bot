from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse
import os
import json

router = APIRouter()

DECISION_LOG_PATH = "logs/decision_log.json"

@router.get("/decisions/recent")
def get_recent_decisions(limit: int = Query(default=10, ge=1, le=100)):
    if not os.path.exists(DECISION_LOG_PATH):
        return []
    try:
        with open(DECISION_LOG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data[-limit:][::-1]  # Последние N записей, от новых к старым
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
