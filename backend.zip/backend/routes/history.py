from fastapi import APIRouter, Query
import json
import os
from datetime import datetime, timedelta

router = APIRouter()

SIGNAL_LOG = "logs/signal_log.json"
TRADE_HISTORY = "logs/trade_history.json"
DECISION_LOG = "logs/decision_log.json"

def load_json_lines(file_path):
    if not os.path.exists(file_path):
        return []
    valid_lines = []
    with open(file_path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            line = line.strip()
            if not line:
                continue
            try:
                valid_lines.append(json.loads(line))
            except json.JSONDecodeError as e:
                print(f"[LOAD ERROR] ❌ Ошибка парсинга строки {i+1} в {file_path}: {e}")
    return valid_lines

def parse_dt(ts):
    if not ts:
        return None
    for fmt in (
        "%Y-%m-%dT%H:%M:%S.%f",  # микросекунды (основной формат)
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d"
    ):
        try:
            return datetime.strptime(ts, fmt)
        except:
            continue
    return None

def safe_parse_date(date_str, default):
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except:
        return default

def normalize_to_range_end(date: datetime) -> datetime:
    return date.replace(hour=23, minute=59, second=59, microsecond=999999)

@router.get("/history/signals")
def get_signal_history(
    from_date: str = Query(None),
    to_date: str = Query(None)
):
    signals = load_json_lines(SIGNAL_LOG)
    now = datetime.now()
    from_dt = safe_parse_date(from_date, now - timedelta(days=7))
    to_dt = normalize_to_range_end(safe_parse_date(to_date, now))

    filtered = []
    for signal in signals:
        ts = parse_dt(signal.get("timestamp") or signal.get("time"))
        if ts and from_dt <= ts <= to_dt:
            filtered.append(signal)

    print(f"[SIGNALS] Всего: {len(signals)}, Отфильтровано: {len(filtered)}")
    return {"signals": filtered[::-1]}

@router.get("/history/trades")
def get_trade_history(
    from_date: str = Query(None),
    to_date: str = Query(None)
):
    trades = load_json_lines(TRADE_HISTORY)
    now = datetime.now()
    from_dt = safe_parse_date(from_date, now - timedelta(days=7))
    to_dt = normalize_to_range_end(safe_parse_date(to_date, now))

    filtered = []
    for trade in trades:
        ts = parse_dt(trade.get("closed_at") or trade.get("timestamp") or trade.get("time"))
        if ts and from_dt <= ts <= to_dt:
            filtered.append(trade)

    print(f"[TRADES] Всего: {len(trades)}, Отфильтровано: {len(filtered)}")
    return {"trades": filtered[::-1]}

@router.get("/history/decisions")
def get_decision_history(
    from_date: str = Query(None),
    to_date: str = Query(None)
):
    decisions = load_json_lines(DECISION_LOG)
    now = datetime.now()
    from_dt = safe_parse_date(from_date, now - timedelta(days=7))
    to_dt = normalize_to_range_end(safe_parse_date(to_date, now))

    filtered = []
    for decision in decisions:
        ts = parse_dt(decision.get("timestamp") or decision.get("time"))
        if ts and from_dt <= ts <= to_dt:
            filtered.append(decision)

    print(f"[DECISIONS] Всего: {len(decisions)}, Отфильтровано: {len(filtered)}")
    return {"decisions": filtered[::-1]}
