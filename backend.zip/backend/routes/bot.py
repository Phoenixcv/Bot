from fastapi import APIRouter
from fastapi.responses import JSONResponse
from utils.settings_manager import load_settings
from utils.event_logger import log_event
from decision_engine import make_decision
from trade_manager import should_open_trade, should_close_trade, register_trade, close_trade
from history_logger import log_trade
from utils.wallet_manager import get_available, update_used, return_to_balance

from binance.client import Client
import os
import asyncio
import threading
from dotenv import load_dotenv
import json

load_dotenv()
router = APIRouter()

API_KEY = os.getenv("BINANCE_API_KEY")
API_SECRET = os.getenv("BINANCE_SECRET_KEY")
client = Client(API_KEY, API_SECRET, testnet=True)

STATUS_FILE = "logs/status.json"
stop_event = threading.Event()

def is_bot_running():
    try:
        with open(STATUS_FILE, "r") as f:
            data = json.load(f)
            return data.get("bot_running", False)
    except:
        return False

def set_bot_running(state: bool):
    os.makedirs("logs", exist_ok=True)
    with open(STATUS_FILE, "w") as f:
        json.dump({"bot_running": state}, f)

@router.get("/bot/status")
def get_status():
    return {"running": is_bot_running()}

@router.post("/bot/start")
def start_bot():
    if is_bot_running():
        return {"status": "already_running", "message": "Бот уже запущен"}

    stop_event.clear()
    thread = threading.Thread(target=lambda: asyncio.run(run_bot()))
    thread.start()
    set_bot_running(True)
    return {"status": "started", "message": "Бот успешно запущен"}

@router.post("/bot/stop")
def stop_bot():
    if not is_bot_running():
        return {"status": "already_stopped", "message": "Бот уже остановлен"}

    stop_event.set()
    set_bot_running(False)
    log_event("shutdown", "🛑 Бот остановлен вручную")
    return {"status": "stopped", "message": "Бот успешно остановлен"}

async def run_bot():
    log_event("startup", "📡 Торговый бот запущен")
    while not stop_event.is_set():
        settings = load_settings()
        symbols = settings.get("symbols", [])
        mode = settings.get("trade_mode", "hourly")
        quantity = float(settings.get("trade_quantity", 0.001))
        interval = settings.get("interval_minutes", 1)

        for symbol in symbols:
            if stop_event.is_set():
                break
            try:
                decision = make_decision(symbol, mode=mode)
                score = decision.get("score")
                action = decision.get("recommendation")
                analysis = decision.get("analysis", {})
                price = analysis.get("price", 0)

                if action == "buy" and should_open_trade(symbol, score):
                    required = price * quantity
                    available = get_available()
                    if available < required:
                        print(f"[LIMIT] {symbol} требует {required:.2f} USDT, доступно: {available:.2f}")
                        continue

                    order = client.order_market_buy(symbol=symbol, quantity=quantity)
                    fills = order.get("fills", [])
                    buy_price = float(fills[0]["price"]) if fills else price

                    register_trade(symbol, buy_price, "buy", quantity)
                    update_used(buy_price * quantity)
                    log_trade(symbol, "BUY", buy_price, quantity, decision)
                    log_event("trade", f"BUY {symbol}", {
                        "price": buy_price, "amount": quantity, "score": score
                    })

                elif action == "sell" and should_close_trade(symbol, score, price):
                    order = client.order_market_sell(symbol=symbol, quantity=quantity)
                    fills = order.get("fills", [])
                    sell_price = float(fills[0]["price"]) if fills else price

                    close_trade(symbol, current_price=sell_price)
                    return_to_balance(sell_price * quantity)
                    log_trade(symbol, "SELL", sell_price, quantity, decision)
                    log_event("trade", f"SELL {symbol}", {
                        "price": sell_price, "amount": quantity, "score": score
                    })

                else:
                    print(f"[NO ACTION] {symbol} → {action}")

            except Exception as e:
                print(f"[BOT ERROR] {symbol} → {str(e)}")
                log_event("error", f"Ошибка торговли {symbol}", {"exception": str(e)})

        await asyncio.sleep(interval * 60)

    print("[STOP] Бот остановлен")
