# /backend/routes/settings.py

from fastapi import APIRouter, HTTPException, Query, Body, Request
from fastapi.responses import JSONResponse
from utils.settings_manager import load_settings, update_settings, save_settings

router = APIRouter()

valid_modes = ["ai", "autonomous", "hybrid"]
valid_models = ["gpt-4", "gpt-3.5", "gpt-3.5-turbo"]
valid_trade_modes = ["hourly", "daily", "weekly"]


@router.get("/settings")
def get_settings():
    """Получить текущие настройки."""
    try:
        settings = load_settings()
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка загрузки настроек: {e}")


@router.post("/settings/update")
async def update_settings_json(request: Request):
    """Обновление настроек через JSON body."""
    try:
        data = await request.json()
        updated = update_settings(data)
        return {"message": "Настройки обновлены", "settings": updated}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.post("/settings")
def update_settings_query(
    mode: str = Query(default=None),
    model: str = Query(default=None),
    interval_minutes: int = Query(default=None, ge=1, le=60),
    balance_limit: float = Query(default=None, ge=1),
    trade_mode: str = Query(default=None)
):
    """Обновление настроек через query-параметры."""
    updates = {}

    if mode:
        if mode not in valid_modes:
            raise HTTPException(status_code=400, detail="Недопустимый режим.")
        updates["mode"] = mode

    if model:
        if model not in valid_models:
            raise HTTPException(status_code=400, detail="Недопустимая модель.")
        updates["model"] = model

    if trade_mode:
        if trade_mode not in valid_trade_modes:
            raise HTTPException(status_code=400, detail="Недопустимый торговый режим.")
        updates["trade_mode"] = trade_mode

    if interval_minutes is not None:
        updates["interval_minutes"] = interval_minutes

    if balance_limit is not None:
        updates["balance_limit"] = balance_limit

    try:
        updated = update_settings(updates)
        return {"message": "Настройки обновлены", "settings": updated}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка обновления настроек: {e}")


@router.post("/settings/chat-model")
def update_chat_model(chat_model: str = Body(..., embed=True)):
    """Обновить модель ChatGPT."""
    if chat_model not in valid_models:
        raise HTTPException(status_code=400, detail="Недопустимая модель.")
    try:
        settings = load_settings()
        settings["chat_model"] = chat_model
        save_settings(settings)
        return {"message": f"Модель обновлена на {chat_model}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка обновления модели: {e}")


@router.post("/settings/symbols")
def update_symbols(symbols: list[str] = Body(..., embed=True)):
    """Обновить список торговых валют."""
    if not 1 <= len(symbols) <= 8:
        raise HTTPException(status_code=400, detail="Допускается от 1 до 8 валют.")
    try:
        updated = update_settings({"symbols": symbols})
        return {"message": "Символы обновлены", "symbols": updated.get("symbols", symbols)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка обновления символов: {e}")


@router.patch("/settings")
async def patch_settings(request: Request):
    """Обновление настроек через PATCH."""
    try:
        body = await request.json()
        updated = update_settings(body)
        return {"message": "Настройки обновлены (PATCH)", "settings": updated}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
