from fastapi import APIRouter, Query, HTTPException
from fastapi.responses import FileResponse
import os

router = APIRouter()

LOG_PATHS = {
    "trade": "logs/trade_history.json",
    "signals": "logs/signal_log.json",
    "decisions": "logs/decision_log.json"
}

@router.get("/logs/export")
def export_logs(file: str = Query(..., description="Тип лога: trade, signals, decisions")):
    path = LOG_PATHS.get(file)
    if not path or not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Файл не найден")

    return FileResponse(path, media_type="application/json", filename=os.path.basename(path))
