# /backend/routes/analyze.py

from fastapi import APIRouter, Request, Query
from fastapi.responses import JSONResponse
from market_analyzer import get_market_analysis
from decision_engine import make_decision
from utils.signal_logger import log_signal
from utils.settings_manager import load_settings

router = APIRouter()


@router.post("/analyze")
async def analyze(request: Request):
    try:
        data = await request.json()
        print("[ANALYZE POST BODY]", data)

        symbol = data.get("symbol", "").strip().upper()
        if not symbol:
            raise ValueError("Символ не указан или пустой")

        print("[ANALYZE SYMBOL]", symbol)

        analysis = get_market_analysis(symbol)
        decision = make_decision(symbol)

        log_signal(symbol, analysis, {
            "recommendation": decision.get("recommendation"),
            "score": decision.get("score"),
            "reason": decision.get("reason"),
            "mode": decision.get("mode"),
            "chatgpt_decision": decision.get("chatgpt_decision"),
            "ai_confirmation": decision.get("ai_confirmation")
        })

        return JSONResponse(content={
            "status": "success",
            "symbol": symbol,
            "analysis": analysis,
            "recommendation": decision.get("recommendation"),
            "score": decision.get("score"),
            "reason": decision.get("reason"),
            "mode": decision.get("mode"),
            "chatgpt_decision": decision.get("chatgpt_decision"),
            "ai_confirmation": decision.get("ai_confirmation")
        })

    except Exception as e:
        print("[ANALYZE ERROR]", e)
        return JSONResponse(status_code=400, content={"status": "error", "error": str(e)})


@router.get("/analyze")
def analyze_one(symbol: str = Query(default="BTCUSDT")):
    try:
        symbol = symbol.strip().upper()
        print("[GET ANALYZE] symbol:", symbol)

        analysis = get_market_analysis(symbol)
        return {
            "symbol": symbol,
            "analysis": analysis
        }
    except Exception as e:
        print("[GET ANALYZE ERROR]", e)
        return JSONResponse(status_code=400, content={"status": "error", "error": str(e)})


@router.get("/analyze/all")
def analyze_all():
    try:
        settings = load_settings()
        symbols = settings.get("symbols", ["BTCUSDT"])
        print("[ANALYZE ALL] symbols:", symbols)

        results = []
        for symbol in symbols:
            try:
                analysis = get_market_analysis(symbol)
                decision = make_decision(symbol)

                log_signal(symbol, analysis, {
                    "recommendation": decision.get("recommendation"),
                    "score": decision.get("score"),
                    "reason": decision.get("reason"),
                    "mode": decision.get("mode"),
                    "chatgpt_decision": decision.get("chatgpt_decision"),
                    "ai_confirmation": decision.get("ai_confirmation")
                })

                results.append({
                    "symbol": symbol,
                    "analysis": analysis,
                    "recommendation": decision.get("recommendation"),
                    "score": decision.get("score"),
                    "reason": decision.get("reason"),
                    "mode": decision.get("mode"),
                    "chatgpt_decision": decision.get("chatgpt_decision"),
                    "ai_confirmation": decision.get("ai_confirmation")
                })
            except Exception as e:
                print(f"[ANALYZE ERROR] {symbol} ->", e)
                results.append({
                    "symbol": symbol,
                    "status": "error",
                    "error": str(e)
                })

        return {"status": "success", "results": results}

    except Exception as e:
        print("[ANALYZE ALL ERROR]", e)
        return JSONResponse(status_code=400, content={"status": "error", "error": str(e)})
