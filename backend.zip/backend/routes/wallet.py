# /backend/routes/wallet.py

from fastapi import APIRouter, Body, Query
from fastapi.responses import JSONResponse
from utils.wallet_manager import (
    get_wallet_status,
    update_trade_limit,
    update_used,
    return_to_balance
)
from trade_manager import load_active_trades
from market_analyzer import get_market_analysis
from datetime import datetime

router = APIRouter()

@router.get("/wallet")
def get_wallet():
    """Получить полное состояние кошелька."""
    try:
        return get_wallet_status()
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@router.get("/wallet/summary")
def wallet_summary():
    """Сводка по кошельку: лимит, зарезервировано, доступно."""
    try:
        status = get_wallet_status()
        return {
            "limit": status["trade_limit"],
            "used": status["used_in_trades"],
            "available": status["available_for_trade"]
        }
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@router.get("/wallet/active_trades")
def get_active_trades(include_closed: bool = Query(default=False)):
    """
    Получить активные сделки (или все, если include_closed=true).
    Добавляет цену, тренд, прибыль, время.
    """
    try:
        trades = load_active_trades()
        result = []
        for symbol, trade in trades.items():
            status = trade.get("status", "unknown")
            if not include_closed and status == "closed":
                continue

            entry_price = float(trade.get("entry_price", 0))
            action = trade.get("action", "buy")
            timestamp = trade.get("timestamp")

            # Анализ рынка
            try:
                analysis = get_market_analysis(symbol)
                current_price = float(analysis.get("price", entry_price))
                trend = analysis.get("trend", "-")
                market_time = analysis.get("timestamp", datetime.utcnow().isoformat())
            except Exception:
                current_price = entry_price
                trend = "-"
                market_time = datetime.utcnow().isoformat()

            # Расчёт прибыли
            if action == "buy":
                pnl = current_price - entry_price
            else:
                pnl = entry_price - current_price

            result.append({
                "symbol": symbol,
                "action": action,
                "entry_price": round(entry_price, 6),
                "current_price": round(current_price, 6),
                "status": status,
                "trend": trend,
                "pnl": round(pnl, 6),
                "timestamp": market_time
            })

        return result
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@router.post("/wallet/limit")
def set_limit(new_limit: float = Body(..., embed=True)):
    """Установить торговый лимит."""
    try:
        update_trade_limit(new_limit)
        return {"status": "ok", "message": "Лимит обновлён"}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@router.post("/wallet/return")
def return_balance(amount: float = Body(..., embed=True)):
    """Вернуть прибыль в общий баланс."""
    try:
        return_to_balance(amount)
        return {"status": "ok", "message": f"Возвращено {amount} USDT"}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@router.post("/wallet/use")
def use_balance(amount: float = Body(..., embed=True)):
    """Зарезервировать сумму под сделку."""
    try:
        update_used(amount)
        return {"status": "ok", "message": f"Использовано {amount} USDT"}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
