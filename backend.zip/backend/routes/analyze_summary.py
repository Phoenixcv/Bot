# backend/routes/analyze_summary.py

from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse
from market_analyzer import get_market_analysis, calculate_signal_score
from utils.settings_manager import load_settings
from utils.wallet_manager import get_wallet_status
from trade_manager import load_last_decisions

router = APIRouter()

MODE_LABELS = {
    "15m": "15 минут",
    "30m": "30 минут",
    "1h": "1 час"
}

TREND_LABELS = {
    "bullish": "восходящий",
    "bearish": "нисходящий",
    "neutral": "боковой"
}

ACTION_LABELS = {
    "buy": "купить (сильный сигнал на рост)",
    "sell": "продать (сильный сигнал на падение)",
    "hold": "удерживать позицию (нет чёткого сигнала)"
}

REASONS = {
    "Сильный положительный сигнал": "индикаторы показывают рост",
    "Сильный отрицательный сигнал": "индикаторы показывают падение",
    "Недостаточно данных": "индикаторы не дали чёткого сигнала на вход"
}

EXCLUDED_FIELDS = {"symbol", "mode", "timestamp", "price", "trend"}

def explain_confidence(score: float) -> str:
    if score >= 0.75:
        return f"{score:.4f} (высокая уверенность)"
    elif score >= 0.5:
        return f"{score:.4f} (средняя уверенность)"
    return f"{score:.4f} (низкая уверенность)"

@router.get("/analyze_summary")
def analyze_summary(symbol: str = Query(default="BTCUSDT"), interval: str = Query(default="15m")):
    try:
        analysis = get_market_analysis(symbol, interval)
        score = calculate_signal_score(analysis)

        if score > 0.75:
            action = "buy"
            reason = "Сильный положительный сигнал"
        elif score < 0.4:
            action = "sell"
            reason = "Сильный отрицательный сигнал"
        else:
            action = "hold"
            reason = "Недостаточно данных"

        last_decisions = load_last_decisions()
        recent_filtered = [
            d for d in last_decisions if d.get("symbol") == symbol
        ][:3]

        indicators = [k for k in analysis.keys() if k not in EXCLUDED_FIELDS and analysis[k] is not None]
        wallet = get_wallet_status()

        return {
            "symbol": symbol,
            "interval": f"{interval} ({MODE_LABELS.get(interval, interval)})",
            "trend": f"{analysis.get('trend')} ({TREND_LABELS.get(analysis.get('trend'), '-')})",
            "price": analysis.get("price"),
            "action": action,
            "action_text": ACTION_LABELS.get(action),
            "score": explain_confidence(score),
            "reason": f"{reason} ({REASONS.get(reason, '-')})",
            "indicators": indicators,
            "recent": recent_filtered,
            "wallet": {
                "available": wallet["available_for_trade"],
                "used": wallet["used_in_trades"],
                "limit": wallet["trade_limit"]
            }
        }

    except Exception as e:
        print("[ANALYZE SUMMARY ERROR]", str(e))
        return JSONResponse(status_code=500, content={"error": str(e)})
