from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from utils.env_manager import get_all_keys, update_keys_with_history, load_key_history
from utils.settings_manager import update_env_file
from dotenv import dotenv_values
import os

router = APIRouter()

SENSITIVE_KEYS = [
    "BINANCE_API_KEY_TEST", "BINANCE_SECRET_KEY_TEST",
    "BINANCE_API_KEY_MAIN", "BINANCE_SECRET_KEY_MAIN",
    "OPENAI_API_KEY"
]

ENV_FILE = ".env"

@router.get("/api-keys")
def get_api_keys():
    """
    Возвращает маскированные текущие ключи из .env
    """
    keys = get_all_keys()
    result = {}
    for key in SENSITIVE_KEYS:
        val = keys.get(key, "")
        result[key] = val[:6] + "..." if val else ""
    return result

@router.post("/api-keys")
async def update_api_keys(request: Request):
    """
    Обновляет один или несколько API-ключей и логирует изменения
    """
    try:
        payload = await request.json()
        if not any(k in payload for k in SENSITIVE_KEYS):
            return JSONResponse(status_code=400, content={"error": "Нет допустимых ключей в запросе"})

        update_keys_with_history(payload)
        return {"status": "success", "message": "Ключи успешно обновлены"}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@router.get("/api-keys/history")
def get_keys_history():
    """
    Возвращает историю обновлений API ключей
    """
    try:
        return load_key_history()
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@router.post("/api-keys/mode")
async def set_binance_mode(request: Request):
    """
    Обновляет флаг USE_TESTNET в .env для переключения между тестовой и основной платформой
    """
    try:
        data = await request.json()
        mode = data.get("mode", "test").lower()
        if mode not in ["test", "main"]:
            return JSONResponse(status_code=400, content={"error": "Режим должен быть 'test' или 'main'"})

        update_env_file({
            "USE_TESTNET": "true" if mode == "test" else "false"
        })

        return {"status": "ok", "mode": mode}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@router.get("/api-keys/mode")
def get_binance_mode():
    """
    Возвращает текущий режим Binance (test/main) на основе USE_TESTNET из .env
    """
    try:
        env = dotenv_values(ENV_FILE)
        use_testnet = env.get("USE_TESTNET", "true").lower() == "true"
        return {"mode": "test" if use_testnet else "main"}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
