from fastapi import APIRouter
from decision_engine import chatgpt_connected
from market_analyzer import get_market_analysis, calculate_signal_score
from datetime import datetime
from utils.settings_manager import get_env_keys, load_settings
from binance.client import Client
from openai import OpenAI
import os

router = APIRouter()

@router.get("/status/chatgpt")
def get_chatgpt_status():
    return {
        "chatgpt_connected": chatgpt_connected,
        "message": (
            "ChatGPT доступен" if chatgpt_connected 
            else "Нет соединения с ChatGPT. Проверьте ключи доступа."
        )
    }

@router.get("/status")
def get_status():
    settings = load_settings()
    symbols = settings.get("symbols", ["BTCUSDT"])
    results = []

    for symbol in symbols:
        try:
            analysis = get_market_analysis(symbol)
            score = calculate_signal_score(analysis)
            results.append({
                "symbol": symbol,
                "analysis": {
                    "price": analysis.get("price"),
                    "trend": analysis.get("trend"),
                    "rsi": analysis.get("rsi"),
                    "macd": analysis.get("macd"),
                    "ema": analysis.get("ema"),
                    "sma": analysis.get("sma"),
                    "volume": analysis.get("volume"),
                    "score": round(score, 4),
                    "timestamp": datetime.utcnow().isoformat()
                }
            })
        except Exception as e:
            results.append({
                "symbol": symbol,
                "error": f"Ошибка анализа: {str(e)}"
            })

    return {
        "status": "ok",
        "data": results
    }

@router.get("/status/check-integrity")
def check_integrity():
    env = get_env_keys(masked=False)
    result = {
        "binance": "unknown",
        "openai": "unknown"
    }

    # Проверка Binance
    try:
        use_testnet = env.get("use_testnet", True)
        api_key = env.get("binance_api_key_test") if use_testnet else env.get("binance_api_key_main")
        secret_key = env.get("binance_secret_key_test") if use_testnet else env.get("binance_secret_key_main")

        if not api_key or not secret_key:
            result["binance"] = "missing_keys"
        else:
            client = Client(api_key, secret_key)
            client.API_URL = "https://testnet.binance.vision/api" if use_testnet else "https://api.binance.com/api"
            _ = client.get_account()
            result["binance"] = "ok"
    except Exception:
        result["binance"] = "error"

    # Проверка OpenAI через клиент >= 1.0.0
    try:
        chatgpt_key = env.get("chatgpt_key")
        if not chatgpt_key:
            result["openai"] = "missing_key"
        else:
            openai_client = OpenAI(api_key=chatgpt_key)
            _ = openai_client.models.list()
            result["openai"] = "ok"
    except Exception as e:
        if "401" in str(e) or "Unauthorized" in str(e):
            result["openai"] = "unauthorized"
        else:
            result["openai"] = "error"

    return result
