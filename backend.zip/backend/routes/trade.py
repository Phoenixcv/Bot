from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
import os
import time
from binance.client import Client

from decision_engine import make_decision
from history_logger import log_trade
from utils.signal_logger import log_decision  # ✅
from utils.settings_manager import load_settings, get_env_keys  # ✅
from utils.wallet_manager import update_used, return_to_balance
from trade_manager import should_open_trade, register_trade, close_trade

router = APIRouter()

# === Настройка ключей и клиента ===
load_dotenv()
env_keys = get_env_keys(masked=False)
use_testnet = env_keys.get("use_testnet", True)

API_KEY = env_keys.get("binance_api_key_test") if use_testnet else env_keys.get("binance_api_key_main")
API_SECRET = env_keys.get("binance_secret_key_test") if use_testnet else env_keys.get("binance_secret_key_main")

client = Client(API_KEY, API_SECRET)
client.API_URL = "https://testnet.binance.vision/api" if use_testnet else "https://api.binance.com/api"

# === Единичная торговля по символу ===
@router.post("/trade")
async def trade(request: Request):
    try:
        data = await request.json()
        symbol = data.get("symbol", "BTCUSDT")

        decision = make_decision(symbol)
        action = decision.get("recommendation")
        score = decision.get("score")
        quantity = decision.get("quantity")
        usdt_to_spend = decision.get("usdt_to_spend")

        if not should_open_trade(symbol, score):
            return JSONResponse(status_code=400, content={"error": "Conditions for opening trade not met"})

        if action == "buy":
            order = client.order_market_buy(symbol=symbol, quantity=quantity)
        else:
            order = client.order_market_sell(symbol=symbol, quantity=quantity)

        fills = order.get("fills", [])
        price = float(fills[0]["price"]) if fills else 0.0

        if action == "buy":
            update_used(usdt_to_spend)
        elif action == "sell":
            return_to_balance(price * quantity)

        log_trade(
            symbol=symbol,
            action=action.upper(),
            price=price,
            quantity=quantity,
            decision_data=decision
        )
        log_decision(symbol, decision)  # ✅

        register_trade(symbol, entry_price=price, action=action)

        return {
            "status": "success",
            "symbol": symbol,
            "recommendation": action,
            "score": score,
            "reason": decision.get("reason"),
            "mode": decision.get("mode"),
            "chatgpt_decision": decision.get("chatgpt_decision"),
            "ai_confirmation": decision.get("ai_confirmation"),
            "orderId": order.get("orderId"),
            "executedQty": order.get("executedQty"),
            "side": order.get("side"),
            "status_order": order.get("status"),
        }

    except Exception as e:
        return JSONResponse(status_code=400, content={"error": str(e)})

# === Массовая торговля по списку символов ===
@router.post("/trade/all")
def trade_all():
    try:
        settings = load_settings()
        symbols = settings.get("symbols", ["BTCUSDT"])

        results = []

        for symbol in symbols:
            decision = make_decision(symbol)
            action = decision.get("recommendation")
            score = decision.get("score")
            quantity = decision.get("quantity")
            usdt_to_spend = decision.get("usdt_to_spend")

            if not should_open_trade(symbol, score):
                results.append({
                    "symbol": symbol,
                    "status": "skipped",
                    "reason": decision.get("reason")
                })
                continue

            try:
                if action == "buy":
                    order = client.order_market_buy(symbol=symbol, quantity=quantity)
                else:
                    order = client.order_market_sell(symbol=symbol, quantity=quantity)

                fills = order.get("fills", [])
                price = float(fills[0]["price"]) if fills else 0.0

                if action == "buy":
                    update_used(usdt_to_spend)
                elif action == "sell":
                    return_to_balance(price * quantity)

                log_trade(
                    symbol=symbol,
                    action=action.upper(),
                    price=price,
                    quantity=quantity,
                    decision_data=decision
                )
                log_decision(symbol, decision)

                register_trade(symbol, entry_price=price, action=action)

                results.append({
                    "symbol": symbol,
                    "status": "success",
                    "action": action,
                    "score": score,
                    "reason": decision.get("reason"),
                    "orderId": order.get("orderId"),
                    "executedQty": order.get("executedQty"),
                    "side": order.get("side"),
                    "orderStatus": order.get("status")
                })

                time.sleep(0.5)

            except Exception as e:
                results.append({
                    "symbol": symbol,
                    "status": "error",
                    "error": str(e)
                })

        return {"status": "completed", "results": results}

    except Exception as e:
        return JSONResponse(status_code=400, content={"error": str(e)})
