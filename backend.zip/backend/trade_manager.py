import json
import os
from datetime import datetime
from utils.settings_manager import load_settings

ACTIVE_TRADES_PATH = "logs/active_trades.json"
SIGNAL_LOG_PATH = "logs/signal_log.json"

# === Загрузка / сохранение активных сделок ===
def load_active_trades():
    if not os.path.exists(ACTIVE_TRADES_PATH):
        return {}
    with open(ACTIVE_TRADES_PATH, "r") as f:
        return json.load(f)

def save_active_trades(trades):
    with open(ACTIVE_TRADES_PATH, "w") as f:
        json.dump(trades, f, indent=2)

# === Условия для открытия сделки ===
def should_open_trade(symbol: str, score: float):
    settings = load_settings()
    threshold = settings.get("entry_threshold", 0.6)
    max_trades = settings.get("max_open_trades", 3)

    trades = load_active_trades()
    open_count = sum(1 for t in trades.values() if t["status"] == "open")

    if symbol in trades and trades[symbol]["status"] == "open":
        print(f"[SKIP] {symbol} уже открыт.")
        return False

    if open_count >= max_trades:
        print(f"[SKIP] Достигнут лимит открытых сделок ({max_trades})")
        return False

    decision = score >= threshold
    print(f"[CHECK OPEN] {symbol} | score: {score} | threshold: {threshold} => {'YES' if decision else 'NO'}")
    return decision

# === Условия для закрытия сделки ===
def should_close_trade(symbol: str, score: float, current_price: float):
    settings = load_settings()
    exit_threshold = settings.get("exit_threshold", 0.5)
    use_trailing = settings.get("trailing", True)
    auto_close = settings.get("enable_auto_close", True)
    trades = load_active_trades()

    if symbol not in trades or trades[symbol]["status"] != "open":
        return False

    trade = trades[symbol]
    entry = trade.get("entry_price", 0)
    action = trade.get("action")
    peak_key = "peak_price"

    if not auto_close or entry == 0:
        return False

    dynamic_score = min(max(score, 0.1), 1.0)
    max_trailing = 0.12
    trailing_stop_pct = (1.0 - dynamic_score) * max_trailing

    close_decision = False

    if use_trailing:
        prev_peak = trade.get(peak_key, entry)

        if action == "buy":
            new_peak = max(current_price, prev_peak)
            trades[symbol][peak_key] = new_peak
            if current_price < new_peak * (1 - trailing_stop_pct):
                close_decision = True

        elif action == "sell":
            new_peak = min(current_price, prev_peak)
            trades[symbol][peak_key] = new_peak
            if current_price > new_peak * (1 + trailing_stop_pct):
                close_decision = True

        if close_decision:
            print(f"[TRAILING CLOSE] {symbol} @ {current_price:.2f} | trailing stop {trailing_stop_pct:.2%}")
            save_active_trades(trades)
            return True

    if score < exit_threshold:
        print(f"[SCORE CLOSE] {symbol} | score: {score} < {exit_threshold}")
        return True

    save_active_trades(trades)
    return False

# === Создание и завершение сделок ===
def register_trade(symbol: str, entry_price: float, action: str, quantity: float):
    trades = load_active_trades()
    trades[symbol] = {
        "entry_price": round(entry_price, 6),
        "quantity": round(quantity, 6),
        "action": action,
        "status": "open",
        "peak_price": round(entry_price, 6),
        "open_time": datetime.utcnow().isoformat(),
        "close_time": None
    }
    print(f"[REGISTER TRADE] {symbol} | {action.upper()} @ {entry_price} x {quantity}")
    save_active_trades(trades)

def close_trade(symbol: str, current_price: float = None):
    trades = load_active_trades()
    if symbol not in trades or trades[symbol]["status"] != "open":
        return

    trade = trades[symbol]
    entry = trade.get("entry_price", 0)
    quantity = trade.get("quantity", 1)
    action = trade.get("action")
    price = current_price or entry

    if entry <= 0 or quantity <= 0:
        pnl = 0
        pnl_percent = 0
    else:
        if action == "buy":
            pnl = (price - entry) * quantity
        else:
            pnl = (entry - price) * quantity
        pnl_percent = (pnl / (entry * quantity)) * 100 if entry and quantity else 0

    trades[symbol]["status"] = "closed"
    trades[symbol]["close_price"] = round(price, 6)
    trades[symbol]["pnl"] = round(pnl, 6)
    trades[symbol]["pnl_percent"] = round(pnl_percent, 2)
    trades[symbol]["close_time"] = datetime.utcnow().isoformat()

    print(f"[CLOSE TRADE] {symbol} => CLOSED | PnL: {pnl:.4f} | {pnl_percent:.2f}%")
    save_active_trades(trades)

# === Последние решения (для frontend) ===
def load_last_decisions(n=3):
    if not os.path.exists(SIGNAL_LOG_PATH):
        return []
    try:
        with open(SIGNAL_LOG_PATH, "r") as f:
            all_signals = json.load(f)
        return all_signals[-n:] if isinstance(all_signals, list) else []
    except Exception as e:
        print("[LOAD DECISIONS ERROR]", e)
        return []
