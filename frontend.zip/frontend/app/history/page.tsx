'use client'
import { useEffect, useState } from 'react'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

type LogType = 'decisions' | 'trades' | 'signals'
type PeriodType = 'day' | 'week' | 'month' | 'custom'

export default function HistoryPage() {
  const [tab, setTab] = useState<LogType>('decisions')
  const [data, setData] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)
  const [period, setPeriod] = useState<PeriodType>('week')
  const [fromDate, setFromDate] = useState<string>('')
  const [toDate, setToDate] = useState<string>('')
  const [details, setDetails] = useState<any | null>(null)

  useEffect(() => {
    applyPeriod(period)
  }, [period])

  function applyPeriod(p: PeriodType) {
    const now = new Date()
    let from: Date

    switch (p) {
      case 'day':
        from = new Date(now)
        from.setDate(now.getDate() - 1)
        break
      case 'week':
        from = new Date(now)
        from.setDate(now.getDate() - 7)
        break
      case 'month':
        from = new Date(now)
        from.setMonth(now.getMonth() - 1)
        break
      case 'custom':
        return
      default:
        from = new Date(now)
    }

    setFromDate(from.toISOString().split('T')[0])
    setToDate(now.toISOString().split('T')[0])
  }

  function fetchData() {
    if (!fromDate || !toDate) return
    const url = `${API_URL}/history/${tab}?from_date=${fromDate}&to_date=${toDate}`
    fetch(url)
      .then(res => res.json())
      .then(res => {
        const key = tab === 'decisions' ? 'decisions' : tab === 'trades' ? 'trades' : 'signals'
        setData(res[key] || [])
        setError(null)
        console.log('✅ Загружено:', res[key])
      })
      .catch(err => {
        setError('Ошибка загрузки данных: ' + err.message)
        console.error('❌ Fetch error:', err)
      })
  }

  function getScoreColor(score: number) {
    if (score >= 0.75) return 'text-green-600'
    if (score >= 0.5) return 'text-yellow-600'
    return 'text-red-600'
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">📊 История</h1>

      <div className="flex gap-4 mb-4">
        {['decisions', 'trades', 'signals'].map(t => (
          <button
            key={t}
            className={`px-4 py-2 rounded ${tab === t ? 'bg-violet-600 text-white' : 'bg-gray-200 text-black'}`}
            onClick={() => setTab(t as LogType)}
          >
            {t === 'decisions' ? 'Решения' : t === 'trades' ? 'Сделки' : 'Сигналы'}
          </button>
        ))}
      </div>

      <div className="flex items-center gap-4 mb-4">
        <select
          value={period}
          onChange={e => setPeriod(e.target.value as PeriodType)}
          className="border px-2 py-1 rounded"
        >
          <option value="day">Сегодня</option>
          <option value="week">Последняя неделя</option>
          <option value="month">Последний месяц</option>
          <option value="custom">Задать период</option>
        </select>

        {period === 'custom' && (
          <>
            <input
              type="date"
              value={fromDate}
              onChange={e => setFromDate(e.target.value)}
              className="border px-2 py-1 rounded"
            />
            <input
              type="date"
              value={toDate}
              onChange={e => setToDate(e.target.value)}
              className="border px-2 py-1 rounded"
            />
          </>
        )}

        <button
          onClick={fetchData}
          className="bg-violet-600 text-white px-4 py-1 rounded hover:bg-violet-700"
        >
          Обновить
        </button>
      </div>

      {error && <p className="text-red-600 mb-4">{error}</p>}
      {data.length === 0 ? (
        <p className="text-gray-500">Нет данных за указанный период</p>
      ) : (
        <div className="overflow-x-auto border rounded">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-3 py-2 text-left">Дата</th>
                <th className="px-3 py-2 text-left">Валюта</th>
                <th className="px-3 py-2 text-left">Событие</th>
                <th className="px-3 py-2 text-left">Сила сигнала<br/>(≥0.75 открытие)</th>
                <th className="px-3 py-2 text-left">...</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item, idx) => (
                <tr key={idx} className="border-t hover:bg-violet-50 cursor-pointer" onClick={() => setDetails(item)}>
                  <td className="px-3 py-2 whitespace-nowrap">{new Date(item.timestamp || item.time || item.closed_at).toLocaleString()}</td>
                  <td className="px-3 py-2">{item.symbol}</td>
                  <td className="px-3 py-2">
                    {tab === 'decisions'
                      ? item.recommendation?.toUpperCase()
                      : tab === 'trades'
                      ? item.action?.toUpperCase()
                      : item.type || 'сигнал'}
                  </td>
                  <td className={`px-3 py-2 ${tab === 'decisions' ? getScoreColor(item.score) : ''}`}>
                    {tab === 'decisions' && item.score?.toFixed(3)}
                    {tab === 'trades' && `${item.profit?.toFixed(2) || 0} USDT`}
                    {tab === 'signals' && item.score?.toFixed(3)}
                  </td>
                  <td className="px-3 py-2 text-violet-600">Подробнее</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {details && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-xl w-full p-6 relative">
            <button onClick={() => setDetails(null)} className="absolute top-2 right-3 text-gray-500 hover:text-black text-xl">×</button>
            <h2 className="text-xl font-bold mb-4">🔍 Подробности</h2>

            <div className="space-y-2 text-sm">
              <div><b>Дата:</b> {new Date(details.timestamp).toLocaleString()}</div>
              <div><b>Валюта:</b> {details.symbol}</div>
              <div><b>Рекомендация:</b> {details.recommendation?.toUpperCase()}</div>
              <div><b>Сила сигнала:</b> <span className={getScoreColor(details.score)}>{details.score?.toFixed(3)}</span></div>
              <div><b>Причина:</b> {details.reason}</div>
              {details.analysis && (
                <div className="pt-2">
                  <b className="block mb-1">📊 Анализ:</b>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {Object.entries(details.analysis).map(([k, v], i) => (
                      <div key={i} className="flex justify-between border-b"><span>{k}</span><span>{String(v)}</span></div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
