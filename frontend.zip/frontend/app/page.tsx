'use client'
import { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'

const API_URL = process.env.NEXT_PUBLIC_API_URL
const CORE_ASSETS = ['BTC', 'ETH', 'USDT', 'BNB', 'SOL', 'ADA', 'XRP', 'DOT']

export default function HomePage() {
  const [symbols, setSymbols] = useState<string[]>([])
  const [analysisData, setAnalysisData] = useState<any[]>([])
  const [balance, setBalance] = useState<any[]>([])
  const [usdt, setUsdt] = useState<any | null>(null)
  const [balanceFilter, setBalanceFilter] = useState<'core' | 'other' | 'all'>('core')
  const [showModal, setShowModal] = useState(false)
  const [selectedAssets, setSelectedAssets] = useState<string[]>([])
  const [error, setError] = useState<string | null>(null)
  const pathname = usePathname()

  useEffect(() => {
    fetch(API_URL + '/settings')
      .then(res => res.json())
      .then(data => {
        const symbolList = data.symbols || []
        setSymbols(symbolList)
        setSelectedAssets(symbolList.map(s => s.replace('USDT', '')))
        localStorage.setItem('symbols', JSON.stringify(symbolList))
      })

    fetch(API_URL + '/balance')
      .then(res => res.json())
      .then(data => {
        if (data.balance) setBalance(data.balance)
        if (data.usdt) setUsdt(data.usdt)
      })
  }, [])

  useEffect(() => {
    fetch(API_URL + '/status')
      .then(res => res.json())
      .then(data => {
        const arr = data.data || data.symbols || []
        if (Array.isArray(arr)) {
          setAnalysisData(arr)
        } else {
          setAnalysisData([])
        }
      })
      .catch(() => setAnalysisData([]))
  }, [symbols])

  const handleAssetToggle = (asset: string) => {
    setSelectedAssets(prev =>
      prev.includes(asset)
        ? prev.filter(a => a !== asset)
        : [...prev, asset].slice(0, 8)
    )
  }

  const handleSelectAll = () => {
    setSelectedAssets(CORE_ASSETS.filter(a => a !== 'USDT').slice(0, 8))
  }

  const handleSaveSymbols = () => {
    const newSymbols = selectedAssets.map(a => a + 'USDT')
    fetch(API_URL + '/settings', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ symbols: newSymbols })
    })
      .then(res => res.json())
      .then(data => {
        setSymbols(data.symbols || [])
        localStorage.setItem('symbols', JSON.stringify(data.symbols || []))
        setShowModal(false)
      })
      .catch(() => alert('Ошибка при сохранении валют'))
  }

  const filteredBalance = balance.filter(b => {
    if (balanceFilter === 'core') return CORE_ASSETS.includes(b.asset)
    if (balanceFilter === 'other') return !CORE_ASSETS.includes(b.asset)
    return true
  })

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Панель управления</h1>

      <div className="flex justify-between items-start gap-4 mb-4 flex-wrap">
        <button
          className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
          onClick={() => setShowModal(true)}
        >
          ➕ Добавить валюты для торгов
        </button>

        {usdt && (
          <div className="bg-white rounded-xl shadow p-4 min-w-[250px]">
            <h2 className="font-semibold text-lg mb-2">USDT</h2>
            <p><strong>Доступно:</strong> {usdt.free}</p>
            <p><strong>Заморожено:</strong> {usdt.locked}</p>
            <p><strong>Резерв для торговли:</strong> {usdt.reserved}</p>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded shadow-lg w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4">Выберите до 8 валют</h2>
            <div className="grid grid-cols-2 gap-2 mb-4">
              {CORE_ASSETS.filter(a => a !== 'USDT').map(asset => (
                <label key={asset} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={selectedAssets.includes(asset)}
                    onChange={() => handleAssetToggle(asset)}
                  />
                  <span>{asset}</span>
                </label>
              ))}
            </div>
            <div className="flex justify-between mb-4">
              <button onClick={handleSelectAll} className="text-sm text-gray-600 underline">Выбрать все</button>
              <div className="flex gap-2">
                <button onClick={() => setShowModal(false)} className="px-4 py-2 border rounded">Отмена</button>
                <button onClick={handleSaveSymbols} className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700">Сохранить</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-6">
        {analysisData.map((item, idx) => (
          <div key={idx} className="bg-white rounded-xl shadow p-4">
            <h2 className="font-semibold text-lg mb-2">{item.symbol}</h2>
            {item.analysis ? (
              <>
                <p><strong>Цена:</strong> {item.analysis.price}</p>
                <p><strong>Тренд:</strong> {item.analysis.trend}</p>
                <p><strong>Время:</strong> {item.analysis.timestamp}</p>
              </>
            ) : (
              <p className="text-red-600">❌ Ошибка анализа</p>
            )}
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow p-4 mt-6">
        <h2 className="font-semibold text-lg mb-2">Другие активы</h2>
        <div className="mb-2 space-x-2">
          <button
            onClick={() => setBalanceFilter('core')}
            className={balanceFilter === 'core' ? 'bg-purple-600 text-white px-3 py-1 rounded' : 'px-3 py-1 border rounded'}
          >Основные</button>
          <button
            onClick={() => setBalanceFilter('other')}
            className={balanceFilter === 'other' ? 'bg-purple-600 text-white px-3 py-1 rounded' : 'px-3 py-1 border rounded'}
          >Остальные</button>
          <button
            onClick={() => setBalanceFilter('all')}
            className={balanceFilter === 'all' ? 'bg-purple-600 text-white px-3 py-1 rounded' : 'px-3 py-1 border rounded'}
          >Все</button>
        </div>

        {filteredBalance.length === 0 && <p>Нет активов</p>}
        <ul className="space-y-1">
          {filteredBalance.map((b, i) => (
            <li key={i}>
              <strong>{b.asset}:</strong> {b.free} доступно / {b.locked} в ордерах
            </li>
          ))}
        </ul>
      </div>

      {error && <p className="text-red-500 mt-4">{error}</p>}
    </div>
  )
}
