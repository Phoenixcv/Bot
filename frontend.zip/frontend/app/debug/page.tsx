'use client'
import { useEffect, useState } from 'react'

export default function DebugPage() {
  const [logs, setLogs] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetch('/logs/debug_log.json')
      .then(res => res.json())
      .then(setLogs)
      .catch(err => setError('Ошибка загрузки debug-лога: ' + err.message))
  }, [])

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🧪 Debug лог</h1>
      {error && <p className="text-red-600 mb-4">{error}</p>}
      {logs.length === 0 ? (
        <p className="text-gray-500">Нет записей в debug-логе</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full border text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-2 py-1">Время</th>
                <th className="px-2 py-1">Валюта</th>
                <th className="px-2 py-1">Score</th>
                <th className="px-2 py-1">Порог</th>
                <th className="px-2 py-1">Решение</th>
                <th className="px-2 py-1">USDT</th>
                <th className="px-2 py-1">Qty</th>
                <th className="px-2 py-1">Режим</th>
                <th className="px-2 py-1">Причина</th>
              </tr>
            </thead>
            <tbody>
              {logs.slice().reverse().map((log, idx) => (
                <tr key={idx} className="border-t">
                  <td className="px-2 py-1 whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</td>
                  <td className="px-2 py-1">{log.symbol}</td>
                  <td className="px-2 py-1">{log.score}</td>
                  <td className="px-2 py-1">{log.threshold}</td>
                  <td className="px-2 py-1">{log.recommendation?.toUpperCase()}</td>
                  <td className="px-2 py-1">{log.usdt_to_spend}</td>
                  <td className="px-2 py-1">{log.quantity}</td>
                  <td className="px-2 py-1">{log.mode}</td>
                  <td className="px-2 py-1 max-w-[300px] truncate" title={log.reason}>{log.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
