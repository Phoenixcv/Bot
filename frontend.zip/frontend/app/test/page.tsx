'use client'
import { useEffect, useState, useRef } from 'react'
import { createChart, LineStyle, IChartApi } from 'lightweight-charts'

const API_URL = process.env.NEXT_PUBLIC_API_URL || ''
const GRAPH_METHODS = ['ema', 'sma', 'bollinger_upper', 'bollinger_middle', 'bollinger_lower']

export default function AnalyzePage() {
  const [symbols, setSymbols] = useState<string[]>([])
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT')
  const [interval, setInterval] = useState('1h')
  const [rangeMode, setRangeMode] = useState('month')
  const [candles, setCandles] = useState<any[]>([])
  const [error, setError] = useState<string | null>(null)
  const chartRef = useRef<HTMLDivElement>(null)
  const chartInstance = useRef<IChartApi | null>(null)

  useEffect(() => {
    fetch(`${API_URL}/settings`)
      .then(res => res.json())
      .then(data => {
        const list = data.symbols || []
        setSymbols(list)
        if (list.length > 0) setSelectedSymbol(list[0])
      })
  }, [])

  const fetchCandles = () => {
    fetch(`${API_URL}/candles?symbol=${selectedSymbol}&interval=${interval}&range_mode=${rangeMode}&limit=1000`)
      .then(res => res.json())
      .then(data => {
        if (!Array.isArray(data)) throw new Error('Неверный формат данных')
        setCandles(data.map(c => ({
          time: c.time,
          open: c.open,
          high: c.high,
          low: c.low,
          close: c.close,
          volume: c.volume
        })))
        setError(null)
      })
      .catch(err => {
        console.error('[CANDLE ERROR]', err)
        setError('Ошибка загрузки свечей')
      })
  }

  useEffect(() => {
    if (selectedSymbol && interval && rangeMode) fetchCandles()
  }, [selectedSymbol, interval, rangeMode])

  useEffect(() => {
    if (!candles.length || !chartRef.current) return

    chartRef.current.innerHTML = ''
    const chart = createChart(chartRef.current, {
      width: chartRef.current.clientWidth,
      height: 400,
      layout: { background: { color: '#fff' }, textColor: '#000' },
      grid: { vertLines: { color: '#eee' }, horzLines: { color: '#eee' } },
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
        borderVisible: true,
        rightOffset: 5
      },
      crosshair: { mode: 1 }
    })

    chartInstance.current = chart
    chart.addCandlestickSeries().setData(candles)
    chart.timeScale().fitContent()
    chart.timeScale().scrollToRealTime()
  }, [candles])

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Аналитика рынка</h1>

      <div className="mb-4 flex gap-4 items-center">
        <select value={selectedSymbol} onChange={e => setSelectedSymbol(e.target.value)} className="p-2 border rounded">
          {symbols.map(sym => <option key={sym} value={sym}>{sym}</option>)}
        </select>
        <select value={interval} onChange={e => setInterval(e.target.value)} className="p-2 border rounded">
          {["1m", "5m", "15m", "1h", "4h", "1d"].map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
        <select value={rangeMode} onChange={e => setRangeMode(e.target.value)} className="p-2 border rounded">
          <option value="month">За месяц</option>
          <option value="year">За год</option>
          <option value="all">Всё время</option>
        </select>
      </div>

      {error && <p className="text-red-500">{error}</p>}
      <div ref={chartRef} className="w-full h-[400px]" />
    </div>
  )
}
