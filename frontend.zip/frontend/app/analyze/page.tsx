'use client'
import { useEffect, useState } from 'react'

const API_URL = process.env.NEXT_PUBLIC_API_URL || ''
const TIMEFRAMES = ['15m', '30m', '1h']

const TREND_COLORS: Record<string, string> = {
  bullish: 'text-green-600',
  bearish: 'text-red-600',
  neutral: 'text-blue-600'
}

const ACTION_COLORS: Record<string, string> = {
  buy: 'text-green-600',
  sell: 'text-red-600',
  hold: 'text-gray-600'
}

const INDICATOR_LABELS: Record<string, string> = {
  atr: 'ATR (волатильность)',
  bollinger_upper: 'Bollinger Upper (верхняя граница)',
  bollinger_middle: 'Bollinger Middle (средняя)',
  bollinger_lower: 'Bollinger Lower (нижняя граница)',
  ema: 'EMA (экспоненциальная средняя)',
  macd: 'MACD (конвергенция/дивергенция)',
  macd_signal: 'MACD Signal (линия сигнала)',
  momentum: 'Momentum (импульс движения)',
  rsi: 'RSI (индекс относительной силы)',
  sma: 'SMA (простая скользящая средняя)',
  stochastic_k: 'Stochastic %K (быстрый стохастик)',
  stochastic_d: 'Stochastic %D (медленный стохастик)',
  wma: 'WMA (взвешенная скользящая средняя)',
  price: 'Price (цена)',
  trend: 'Trend (тренд)',
  timestamp: 'Timestamp (время)',
  mode: 'Mode (режим)',
  symbol: 'Symbol (символ)'
}

export default function AnalyzeSummaryPage() {
  const [symbols, setSymbols] = useState<string[]>([])
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT')
  const [results, setResults] = useState<Record<string, any>>({})
  const [loading, setLoading] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetch(`${API_URL}/settings`)
      .then(res => res.json())
      .then(json => {
        const list = json.symbols || []
        setSymbols(list)
        if (list.length > 0) setSelectedSymbol(list[0])
      })
      .catch(err => console.error('Ошибка загрузки валют:', err))
  }, [])

  useEffect(() => {
    if (!selectedSymbol) return
    setError(null)
    setLoading(true)

    const fetchAll = async () => {
      const resultsObj: Record<string, any> = {}
      for (const tf of TIMEFRAMES) {
        try {
          const res = await fetch(`${API_URL}/analyze_summary?symbol=${selectedSymbol}&interval=${tf}`)
          if (!res.ok) throw new Error(`Ошибка по таймфрейму ${tf}`)
          const data = await res.json()
          resultsObj[tf] = data
        } catch (err: any) {
          console.error(`[ERROR ${tf}]`, err)
          setError(`Ошибка получения анализа для ${tf}: ${err.message}`)
        }
      }
      setResults(resultsObj)
      setLoading(false)
    }

    fetchAll()
    const timer = setInterval(fetchAll, 60000)
    return () => clearInterval(timer)
  }, [selectedSymbol])

  return (
    <div className="p-4 relative">
      <h1 className="text-2xl font-bold mb-6">📊 Расширенный анализ</h1>

      <div className="mb-6 flex gap-4 flex-wrap items-center">
        <label className="font-semibold">Валюта:</label>
        <select
          value={selectedSymbol}
          onChange={e => setSelectedSymbol(e.target.value)}
          className="p-2 border rounded"
        >
          {symbols.map(sym => (
            <option key={sym} value={sym}>{sym}</option>
          ))}
        </select>
      </div>

      {loading && (
        <div className="text-center text-blue-600 font-medium mb-4 animate-pulse">
          ⏳ Ожидайте обновления данных...
        </div>
      )}

      {error && <p className="text-red-600 font-semibold mb-4">{error}</p>}

      <div className="grid gap-6">
        {TIMEFRAMES.map(tf => {
          const data = results[tf]
          if (!data || data.symbol !== selectedSymbol) return null

          const trendColor = TREND_COLORS[data.trend?.split(' ')[0]] || ''
          const actionColor = ACTION_COLORS[data.action] || ''

          return (
            <div key={tf} className="bg-white p-4 rounded-xl shadow">
              <h2 className="text-lg font-semibold mb-2">Анализ: {data.interval}</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4 text-sm">
                <p><strong>Тренд:</strong> <span className={trendColor}>{data.trend}</span></p>
                <p><strong>Цена:</strong> {data.price}</p>
                <p><strong>Действие:</strong> <span className={actionColor}>{data.action?.toUpperCase()} ({data.action_text})</span></p>
                <p><strong>Уверенность:</strong> {data.score}</p>
                <p><strong>Причина:</strong> {data.reason}</p>
              </div>

              {Array.isArray(data.indicators) && data.indicators.length > 0 && (
                <>
                  <h3 className="font-semibold mb-2">📍 Использованные индикаторы</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm text-gray-700">
                    {data.indicators.map((ind: string) => (
                      <p key={ind}>
                        <span className="font-medium">•</span>{' '}
                        {INDICATOR_LABELS[ind.toLowerCase()] || ind.toUpperCase()}
                      </p>
                    ))}
                  </div>
                </>
              )}

              {Array.isArray(data.recent) && data.recent.length > 0 && (
                <div className="mt-4 text-sm">
                  <h3 className="font-semibold mb-2">🕒 Последние 3 анализа по {selectedSymbol}</h3>
                  <ul className="space-y-1">
                    {data.recent
                      .filter((item: any) => item.symbol === selectedSymbol)
                      .map((item: any, idx: number) => (
                        <li key={idx} className="text-gray-700">
                          <strong>{item.time}</strong>: Тренд: {item.trend || '-'}, Цена: {item.price || '-'},
                          Действие: {(item.action || '').toUpperCase() || '-'}, Уверенность: {(item.score ?? 0).toFixed(3)}
                        </li>
                      ))}
                  </ul>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
