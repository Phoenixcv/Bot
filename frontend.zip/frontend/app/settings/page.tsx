'use client'
import { useEffect, useState } from 'react'

const API_URL = process.env.NEXT_PUBLIC_API_URL || ''

export default function SettingsPage() {
  const [envKeys, setEnvKeys] = useState<any>({})
  const [error, setError] = useState<string | null>(null)
  const [status, setStatus] = useState<string | null>(null)
  const [showModal, setShowModal] = useState<string | null>(null)
  const [inputs, setInputs] = useState<any>({})
  const [history, setHistory] = useState<any[]>([])
  const [showHistory, setShowHistory] = useState(false)
  const [mode, setMode] = useState('test')
  const [integrity, setIntegrity] = useState<any>({})

  const keyGroups = [
    {
      label: '🧪 Тестовая Binance',
      keys: ['BINANCE_API_KEY_TEST', 'BINANCE_SECRET_KEY_TEST']
    },
    {
      label: '📈 Основная Binance',
      keys: ['BINANCE_API_KEY_MAIN', 'BINANCE_SECRET_KEY_MAIN']
    },
    {
      label: '🤖 ChatGPT',
      keys: ['OPENAI_API_KEY']
    }
  ]

  const fetchAll = async () => {
    try {
      const [keysRes, modeRes, integrityRes] = await Promise.all([
        fetch(`${API_URL}/api-keys`),
        fetch(`${API_URL}/api-keys/mode`),
        fetch(`${API_URL}/status/check-integrity`)
      ])

      const keys = await keysRes.json()
      const modeData = await modeRes.json()
      const integrity = await integrityRes.json()

      setEnvKeys(keys)
      setInputs(keys)
      setMode(modeData.mode || 'test')
      setIntegrity(integrity)
    } catch (err: any) {
      setError('Ошибка загрузки данных: ' + err.message)
    }
  }

  useEffect(() => {
    fetchAll()
  }, [])

  useEffect(() => {
    if (status) {
      const timeout = setTimeout(() => setStatus(null), 5000)
      return () => clearTimeout(timeout)
    }
  }, [status])

  const handleSaveKeys = async () => {
    const updates: any = {}
    keyGroups.flatMap(group => group.keys).forEach(k => {
      if (inputs[k]) updates[k] = inputs[k]
    })

    try {
      const res = await fetch(`${API_URL}/api-keys`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      })
      if (!res.ok) throw new Error('Ошибка при сохранении')
      setStatus('Ключи успешно обновлены')
      setShowModal(null)
      fetchAll()
    } catch (e) {
      setError('Ошибка при сохранении ключей')
    }
  }

  const handleChangeMode = async (newMode: string) => {
    setMode(newMode)
    await fetch(`${API_URL}/api-keys/mode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode: newMode })
    })
    fetchAll()
  }

  const loadHistory = async () => {
    try {
      const res = await fetch(API_URL + '/api-keys/history')
      const data = await res.json()
      setHistory(data.reverse())
      setShowHistory(true)
    } catch (e) {
      setError('Ошибка загрузки истории ключей')
    }
  }

  const blockBorder = (groupLabel: string) => {
    if (groupLabel.includes('Тестовая') && integrity.binance !== 'ok' && mode === 'test') return 'border-red-500'
    if (groupLabel.includes('Основная') && integrity.binance !== 'ok' && mode === 'main') return 'border-red-500'
    if (groupLabel.includes('ChatGPT') && integrity.openai !== 'ok') return 'border-red-500'
    if (groupLabel.includes('Тестовая') && integrity.binance === 'ok' && mode === 'test') return 'border-yellow-500'
    if (groupLabel.includes('Основная') && integrity.binance === 'ok' && mode === 'main') return 'border-green-500'
    if (groupLabel.includes('ChatGPT') && integrity.openai === 'ok') return 'border-blue-500'
    return 'border-gray-300'
  }

  const modeStatus = () => {
    if (integrity.binance === 'ok') return '✅ Binance работает'
    if (integrity.binance === 'missing_keys') return '❌ Ключи Binance отсутствуют'
    if (integrity.binance === 'error') return '❌ Ошибка подключения к Binance'
    return '⏳ Проверка...'
  }

  return (
    <div className="p-6 pb-24">
      <h1 className="text-2xl font-bold mb-6">🔐 API Ключи</h1>

      {error && <p className="text-red-500 mb-3">{error}</p>}
      {status && <p className="text-green-600 mb-3">{status}</p>}

      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div className="flex gap-4">
            <button
              onClick={() => handleChangeMode('test')}
              className={`px-6 py-2 rounded font-semibold border ${mode === 'test' ? 'bg-yellow-100 text-yellow-800 border-yellow-500' : 'bg-white text-gray-600 border-gray-300'}`}
            >
              🧪 Тестовый
            </button>
            <button
              onClick={() => handleChangeMode('main')}
              className={`px-6 py-2 rounded font-semibold border ${mode === 'main' ? 'bg-green-100 text-green-800 border-green-500' : 'bg-white text-gray-600 border-gray-300'}`}
            >
              📈 Боевой
            </button>
          </div>
          <div className="text-sm text-gray-700 font-medium">
            {modeStatus()}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {keyGroups.map(group => (
          <div key={group.label} className={`bg-white rounded-xl shadow p-4 border-2 ${blockBorder(group.label)}`}>
            <h2 className="font-semibold text-lg mb-3">{group.label}</h2>
            {group.keys.map(key => (
              <div key={key} className="flex items-center justify-between py-2 px-3 border rounded border-gray-200">
                <span className="font-mono text-sm text-gray-700">{key}</span>
                <div className="flex gap-2">
                  <span className="font-mono text-sm text-gray-500">{envKeys[key] || '[не задан]'}</span>
                  <button
                    onClick={() => setShowModal(key)}
                    className="text-sm text-purple-600 underline hover:text-purple-800"
                  >Изменить</button>
                </div>
              </div>
            ))}
          </div>
        ))}

        <button
          onClick={loadHistory}
          className="mt-4 px-6 py-2 bg-gray-700 text-white rounded hover:bg-gray-800"
        >Показать историю изменений</button>
      </div>
    </div>
  )
}
