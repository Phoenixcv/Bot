'use client'
import { useEffect, useState } from 'react'
import { format } from 'date-fns'

const API_URL = process.env.NEXT_PUBLIC_API_URL || ''
const MODES = ['autonomous', 'hybrid', 'ai']
const GPT_MODELS = ['gpt-3.5', 'gpt-4']
const DEFAULT_MODEL = 'gpt-3.5'
const DEAL_TYPES = ['percent', 'manual']

export default function TradePage() {
  const [mode, setMode] = useState('autonomous')
  const [gptModel, setGptModel] = useState(DEFAULT_MODEL)
  const [limit, setLimit] = useState(100)
  const [used, setUsed] = useState(0)
  const [symbols, setSymbols] = useState<string[]>([])
  const [selected, setSelected] = useState<string[]>([])
  const [activeTrades, setActiveTrades] = useState<any[]>([])
  const [status, setStatus] = useState<string | null>(null)
  const [showLimitModal, setShowLimitModal] = useState(false)
  const [newLimit, setNewLimit] = useState('')
  const [showSymbolModal, setShowSymbolModal] = useState(false)
  const [dealType, setDealType] = useState<'percent' | 'manual'>('percent')
  const [dealValue, setDealValue] = useState(25)
  const [expandedTrade, setExpandedTrade] = useState<any | null>(null)
  const [botRunning, setBotRunning] = useState<boolean>(false)
  const [loadingBot, setLoadingBot] = useState(true)


  const calcProfit = (entry: number, current: number, action: string) => {
    const fee = 0.001
    const multiplier = action === 'buy' ? 1 : -1
    const net = (current * (1 - fee)) - (entry * (1 + fee))
    const percent = ((net / entry) * 100).toFixed(2)
    const usdt = net.toFixed(2)
    const isProfit = multiplier * net >= 0
    return { usdt, percent, isProfit }
  }

  useEffect(() => {
  fetch(`${API_URL}/settings`)
    .then(res => res.json())
    .then(data => {
      setLimit(data.balance_limit || 100)
      setSymbols(data.symbols || [])
      setSelected(data.symbols || [])
      setMode(data.mode || 'autonomous')
      setGptModel(data.model || DEFAULT_MODEL)
      setDealType(data.deal_type || 'percent')
      setDealValue(data.deal_value || 25)
    })

  fetch(`${API_URL}/wallet/summary`)
    .then(res => res.json())
    .then(data => setUsed(data.used || 0))

  fetch(`${API_URL}/wallet/active_trades`)
    .then(res => res.json())
    .then(data => setActiveTrades(
      Object.entries(data).map(([symbol, info]: any) => ({ symbol, ...info }))
    ))

  // 👇 Проверка, запущен ли бот
  fetch(`${API_URL}/bot/status`)
  .then(res => res.json())
  .then(data => {
    setBotRunning(data.running || false)
    setLoadingBot(false)
  })
  .catch(() => {
    setBotRunning(false)
    setLoadingBot(false)
  })

}, [])


  const saveLimit = () => {
    const value = parseFloat(newLimit)
    if (!isNaN(value)) {
      fetch(`${API_URL}/settings`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ balance_limit: value })
      }).then(() => {
        setLimit(value)
        setShowLimitModal(false)
      })
    }
  }

  const saveSymbols = () => {
    fetch(`${API_URL}/settings/symbols`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ symbols: selected })
    }).then(() => setShowSymbolModal(false))
  }

  const saveSettings = () => {
    fetch(`${API_URL}/settings`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode, model: gptModel, deal_type: dealType, deal_value: dealValue })
    })
  }

  const toggleSymbol = (s: string) => {
    if (selected.includes(s)) {
      setSelected(prev => prev.filter(v => v !== s))
    } else {
      if (selected.length < 8) {
        setSelected(prev => [...prev, s])
      }
    }
  }

const toggleBot = () => {
  const endpoint = botRunning ? '/bot/stop' : '/bot/start'
  const actionText = botRunning ? 'Остановка...' : 'Запуск...'
  setStatus(`⏳ ${actionText}`)
  saveSettings()

  fetch(`${API_URL}${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  })
    .then(res => res.json())
    .then(data => {
      setBotRunning(!botRunning)
      setStatus(botRunning ? '🛑 Бот остановлен' : '✅ Бот запущен')
    })
    .catch(err => {
      console.error(err)
      setStatus(`❌ Ошибка ${botRunning ? 'остановки' : 'запуска'}`)
    })
}


  const colorByAction = (action: string) => {
    return action === 'buy' ? 'text-green-600' : action === 'sell' ? 'text-red-600' : 'text-gray-600'
  }

  return (
    <div className="p-6">
      <div className="flex flex-wrap justify-between items-start mb-6 gap-4">
        <div className="flex flex-wrap gap-6">
          <div>
            <label className="block font-semibold mb-1">Режим торговли:</label>
            <select value={mode} onChange={e => setMode(e.target.value)} className="p-2 border rounded">
              {MODES.map(m => (
                <option key={m} value={m}>
                  {m === 'autonomous' && 'Автономный'}
                  {m === 'hybrid' && 'Гибрид'}
                  {m === 'ai' && 'ИИ'}
                </option>
              ))}
            </select>
          </div>
          {(mode === 'ai' || mode === 'hybrid') && (
            <div>
              <label className="block font-semibold mb-1">Модель ChatGPT:</label>
              <select value={gptModel} onChange={e => setGptModel(e.target.value)} className="p-2 border rounded">
                {GPT_MODELS.map(m => (<option key={m} value={m}>{m}</option>))}
              </select>
            </div>
          )}
          <div>
            <label className="block font-semibold mb-1">Сумма сделки:</label>
            <select value={dealType} onChange={e => setDealType(e.target.value as 'percent' | 'manual')} className="p-2 border rounded mr-2">
              {DEAL_TYPES.map(t => (
                <option key={t} value={t}>{t === 'percent' ? 'Процент от лимита' : 'Ручной ввод'}</option>
              ))}
            </select>
            <input
              type="number"
              value={dealValue}
              onChange={e => setDealValue(parseFloat(e.target.value))}
              className="p-2 border rounded w-32"
              placeholder={dealType === 'percent' ? '% от лимита' : 'USDT'}
            />
          </div>
        </div>
        <div className="flex flex-col items-end">
         {loadingBot ? (
  <div className="text-gray-500 px-6 py-2">⌛ Проверка статуса...</div>
) : (
  <button
    onClick={toggleBot}
    className={`px-6 py-2 rounded text-white ${botRunning ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}
  >
    {botRunning ? '🛑 Остановить бота' : '🚀 Запустить бота'}
  </button>
)}


          {status && <span className="text-sm mt-1 font-medium text-right">{status}</span>}
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 shadow mb-6">
        <h2 className="font-semibold text-lg mb-4">💰 Торговый лимит</h2>
        <p>Лимит: <strong>{limit} USDT</strong></p>
        <p>Зарезервировано: <strong>{used} USDT</strong></p>
        <p>Доступно: <strong>{(limit - used).toFixed(2)} USDT</strong></p>
        <button onClick={() => setShowLimitModal(true)} className="mt-3 px-4 py-2 rounded bg-purple-600 text-white hover:bg-purple-700">
          Изменить лимит
        </button>
      </div>

      <div className="bg-white rounded-xl p-4 shadow mb-6">
        <h2 className="font-semibold text-lg mb-4">📈 Валюты для торговли</h2>
        <p>Выбрано: {selected.join(', ')}</p>
        <button onClick={() => setShowSymbolModal(true)} className="mt-3 px-4 py-2 rounded bg-purple-600 text-white hover:bg-purple-700">
          Выбрать валюты
        </button>
      </div>

     <div className="bg-white rounded-xl p-4 shadow mb-6">
  <h2 className="font-semibold text-lg mb-4">📊 Активные сделки</h2>
  {activeTrades.length === 0 ? (
    <p className="text-gray-500">Нет открытых сделок</p>
  ) : (
    <table className="w-full text-sm">
      <thead>
        <tr className="text-left border-b">
          <th className="py-1">Дата</th>
          <th>Валюта</th>
          <th>Цена входа</th>
          <th>Текущая цена</th>
          <th>Прибыль</th>
          <th>Тренд</th>
          <th>Действие</th>
          <th>Статус</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
  {activeTrades.map((trade, idx) => {
    const quantity = parseFloat(trade.quantity || 0)
    const entry = parseFloat(trade.entry_price || 0)
    const current = parseFloat(trade.current_price || 0)
    const coin = trade.symbol?.replace('USDT', '') || ''
    const fee = quantity * 0.001
    const netQty = quantity - fee
    const cost = quantity * entry
    const sell = netQty * current
    const pnl = sell - cost
    const pnlPercent = (pnl / cost) * 100

    return (
      <tr key={idx} className="border-b">
        <td>{trade.timestamp ? format(new Date(trade.timestamp), 'yyyy-MM-dd HH:mm') : '-'}</td>
        <td>{trade.symbol}</td>
        <td>{entry.toFixed(2)}</td>
        <td>{current.toFixed(2)}</td>
        <td className={pnl >= 0 ? 'text-green-600' : 'text-red-600'}>
          {pnl >= 0 ? '+' : ''}{pnl.toFixed(2)} USDT ({pnlPercent.toFixed(2)}%)
        </td>
        <td className={
          trade.trend === 'bullish' ? 'text-green-600' :
          trade.trend === 'bearish' ? 'text-red-600' :
          'text-gray-500'
        }>
          {trade.trend || '-'}
        </td>
        <td className={colorByAction(trade.action)}>{trade.action?.toUpperCase()}</td>
        <td className={trade.status === 'open' ? 'text-blue-600' : 'text-gray-500'}>
          {trade.status}
        </td>
        <td>
          <button
            onClick={() => setExpandedTrade(trade)}
            className="text-blue-600 hover:underline"
          >
            Подробнее
          </button>
        </td>
      </tr>
    )
  })}
</tbody>

    </table>
  )}
</div>


      {/* === Модальные окна === */}
      {showLimitModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow w-full max-w-sm">
            <h3 className="text-lg font-semibold mb-4">Новый торговый лимит (USDT)</h3>
            <input type="number" className="w-full p-2 border rounded mb-4"
              value={newLimit} onChange={e => setNewLimit(e.target.value)} placeholder="например, 150"
            />
            <div className="flex justify-end space-x-3">
              <button onClick={() => setShowLimitModal(false)} className="px-4 py-2 border rounded">Отмена</button>
              <button onClick={saveLimit} className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700">Сохранить</button>
            </div>
          </div>
        </div>
      )}

      {showSymbolModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow w-full max-w-lg">
            <h3 className="text-lg font-semibold mb-4">Выберите валюты (до 8)</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-[300px] overflow-y-auto">
              {symbols.map(sym => (
                <label key={sym} className="inline-flex items-center space-x-2">
                  <input
                    type="checkbox" checked={selected.includes(sym)}
                    onChange={() => toggleSymbol(sym)}
                  />
                  <span>{sym}</span>
                </label>
              ))}
            </div>
            <div className="mt-4 flex justify-between">
              <button onClick={() => setSelected(symbols)} className="text-sm text-gray-600 underline">Выбрать все</button>
              <div className="space-x-2">
                <button onClick={() => setShowSymbolModal(false)} className="px-4 py-2 border rounded">Закрыть</button>
                <button onClick={saveSymbols} className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700">Сохранить</button>
              </div>
            </div>
          </div>
        </div>
           )}

      {expandedTrade && (
  <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
    <div className="bg-white p-6 rounded-xl shadow max-w-lg w-full text-sm">
      <h3 className="text-lg font-semibold mb-4">📋 Подробности сделки</h3>

      {(() => {
        const quantity = parseFloat(expandedTrade.quantity || 0)
        const entry = parseFloat(expandedTrade.entry_price || 0)
        const current = parseFloat(expandedTrade.current_price || 0)
        const coin = expandedTrade.symbol.replace('USDT', '')
        const fee = quantity * 0.001
        const netQty = quantity - fee
        const costUSDT = quantity * entry
        const feeUSDT = fee * entry
        const totalUSDT = netQty * entry
        const sellValue = netQty * current
        const pnl = sellValue - costUSDT

        return (
          <div className="space-y-2">
            <p><strong>Куплено:</strong> {quantity.toFixed(6)} {coin} @ {entry} (≈ {costUSDT.toFixed(2)} USDT)</p>
            <p><strong>Комиссия:</strong> 0.0001 ({fee.toFixed(6)} {coin} ≈ {feeUSDT.toFixed(2)} USDT)</p>
            <p><strong>Итого:</strong> {netQty.toFixed(6)} {coin} (≈ {totalUSDT.toFixed(2)} USDT на руках)</p>
            <p><strong>Продажа:</strong> {netQty.toFixed(6)} × {current} = {sellValue.toFixed(2)} USDT</p>
            <p className={`font-semibold ${pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {pnl >= 0 ? '✅ Прибыль' : '🔻 Убыток'}: ≈ {pnl.toFixed(4)} USDT
            </p>
          </div>
        )
      })()}

      <div className="mt-4 text-right">
        <button
          onClick={() => setExpandedTrade(null)}
          className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700"
        >
          Закрыть
        </button>
      </div>
    </div>
  </div>
)}



    </div>
  )
}
