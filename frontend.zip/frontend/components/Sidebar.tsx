'use client'
import { usePathname } from 'next/navigation'

export default function Sidebar() {
  const pathname = usePathname()

  const navLinks = [
    { href: '/', label: '🏠 Главная' },
    { href: '/analyze', label: '📈 Аналитика' },
    { href: '/trade', label: '💼 Торговля' },
    { href: '/history', label: '📜 История' },
    { href: '/settings', label: '⚙️ Настройки' }
  ]

  return (
    <aside className="w-64 bg-purple-700 text-white flex flex-col p-4 space-y-4">
      <h1 className="text-xl font-bold">Trading Bot</h1>
      <nav className="flex flex-col space-y-2">
        {navLinks.map(({ href, label }) => (
          <a
            key={href}
            href={href}
            className={`p-2 rounded hover:bg-purple-600 ${
              pathname === href ? 'bg-purple-600' : ''
            }`}
          >
            {label}
          </a>
        ))}
      </nav>
    </aside>
  )
}
