type Props = {
  value: string
  onChange: (val: string) => void
  placeholder?: string
}

export default function Input({ value, onChange, placeholder }: Props) {
  return (
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="border p-2 rounded w-full"
    />
  )
}
