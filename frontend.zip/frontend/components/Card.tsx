export default function Card({ title, children }: { title: string, children: React.ReactNode }) {
  return (
    <div className="bg-white p-4 rounded-xl shadow space-y-2">
      <h2 className="font-semibold text-lg">{title}</h2>
      {children}
    </div>
  )
}
