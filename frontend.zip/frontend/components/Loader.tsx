export default function Loader() {
  return (
    <div className="animate-pulse text-gray-500">Загрузка...</div>
  )
}
