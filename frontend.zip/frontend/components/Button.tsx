type Props = {
  children: React.ReactNode
  onClick: () => void
  disabled?: boolean
}

export default function Button({ children, onClick, disabled }: Props) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`bg-purple-700 hover:bg-purple-800 text-white px-4 py-2 rounded ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      {children}
    </button>
  )
}
